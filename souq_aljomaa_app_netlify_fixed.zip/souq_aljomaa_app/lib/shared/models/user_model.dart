/// أدوار المستخدمين الأربعة في المنصة (تطابق نوع user_role في قاعدة البيانات)
enum UserRole { customer, seller, deliveryCompany, admin }

enum AccountStatus { pending, active, suspended, rejected }

extension UserRoleDb on UserRole {
  static UserRole fromDb(String value) {
    switch (value) {
      case 'customer':
        return UserRole.customer;
      case 'seller':
        return UserRole.seller;
      case 'delivery_company':
        return UserRole.deliveryCompany;
      case 'admin':
        return UserRole.admin;
    }
    throw ArgumentError('دور غير معروف: $value');
  }

  String toDb() {
    switch (this) {
      case UserRole.customer:
        return 'customer';
      case UserRole.seller:
        return 'seller';
      case UserRole.deliveryCompany:
        return 'delivery_company';
      case UserRole.admin:
        return 'admin';
    }
  }
}

class UserModel {
  /// معرّف المستخدم (uuid) — نفس id في Supabase Auth (auth.users)
  final String id;
  final String? phone;
  final String? email;
  final String? fullName;
  final UserRole role;
  final AccountStatus status;
  final String? avatarUrl;

  const UserModel({
    required this.id,
    required this.phone,
    this.email,
    this.fullName,
    required this.role,
    required this.status,
    this.avatarUrl,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'] as String,
      phone: json['phone'] as String?,
      email: json['email'] as String?,
      fullName: json['full_name'] as String?,
      role: UserRoleDb.fromDb(json['role'] as String),
      status: AccountStatus.values.byName(json['status'] as String),
      avatarUrl: json['avatar_url'] as String?,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'phone': phone,
        'email': email,
        'full_name': fullName,
        'role': role.toDb(),
        'status': status.name,
        'avatar_url': avatarUrl,
      };

  UserModel copyWith({
    String? email,
    String? fullName,
    AccountStatus? status,
    String? avatarUrl,
  }) {
    return UserModel(
      id: id,
      phone: phone,
      email: email ?? this.email,
      fullName: fullName ?? this.fullName,
      role: role,
      status: status ?? this.status,
      avatarUrl: avatarUrl ?? this.avatarUrl,
    );
  }
}
