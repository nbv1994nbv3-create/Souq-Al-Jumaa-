import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'core/routing/app_router.dart';
import 'core/theme/app_theme.dart';

/// جذر التطبيق. اتجاه RTL يُضبط تلقائيًا من MaterialApp بمجرد ضبط
/// locale إلى 'ar' — وكل الشاشات المبنية بـ Directionality الافتراضي
/// سترث الاتجاه من اليمين إلى اليسار دون أي إعداد إضافي.
class SouqAljomaaApp extends ConsumerWidget {
  const SouqAljomaaApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return MaterialApp.router(
      title: 'سوق الجمعة',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      routerConfig: appRouter,

      // -------- دعم اللغة العربية و RTL --------
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
    );
  }
}
