/// مسارات الـ API — تُطابق الكيانات في مخطط قاعدة البيانات.
class ApiEndpoints {
  ApiEndpoints._();

  // المصادقة
  static const login = '/auth/login';
  static const register = '/auth/register';
  static const refreshToken = '/auth/refresh';

  // الأقسام والمنتجات
  static const categories = '/categories';
  static String productsByCategory(int categoryId) => '/categories/$categoryId/products';
  static String product(int id) => '/products/$id';
  static const offers = '/products/offers';
  static const search = '/products/search';

  // السلة والمفضلة
  static const favorites = '/favorites';

  // العناوين
  static const addresses = '/customer/addresses';

  // التوصيل
  static String deliveryOptions(int addressId) => '/delivery/options?address_id=$addressId';

  // الطلبات
  static const orders = '/orders';
  static String order(int id) => '/orders/$id';
  static String confirmDelivery(int orderId) => '/orders/$orderId/confirm-delivery'; // إدخال OTP

  // البائع
  static const sellerProducts = '/seller/products';
  static const sellerOrders = '/seller/orders';
  static const sellerSalesReport = '/seller/reports/sales';

  // شركة التوصيل
  static const deliveryCompanyRegister = '/delivery-company/register';
  static const deliveryCompanyCoverageAreas = '/delivery-company/coverage-areas';
  static const deliveryCompanyRequests = '/delivery-company/requests';
  static String deliveryRequestStatus(int assignmentId) => '/delivery-company/requests/$assignmentId/status';

  // الإدارة
  static const adminSellers = '/admin/sellers';
  static const adminDeliveryCompanies = '/admin/delivery-companies';
  static const adminComplaints = '/admin/complaints';
  static const adminReports = '/admin/reports';
}
