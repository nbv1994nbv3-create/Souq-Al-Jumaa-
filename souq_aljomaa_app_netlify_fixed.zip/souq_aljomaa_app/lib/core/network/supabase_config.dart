import 'package:supabase_flutter/supabase_flutter.dart';

/// إعدادات مشروع Supabase الخاص بتطبيق سوق الجمعة.
///
/// المفتاح هنا هو anon/publishable key وهو آمن للتضمين داخل تطبيق
/// العميل (client-side) لأن صلاحياته محكومة بسياسات RLS في قاعدة
/// البيانات. لا تضع مطلقًا service_role key هنا أو في أي كود عميل.
class SupabaseConfig {
  SupabaseConfig._();

  static const String projectUrl = 'https://owsbngtybmueqecapiap.supabase.co';

  static const String anonKey =
      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im93c2JuZ3R5Ym11ZXFlY2FwaWFwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODk0ODM0MTgsImV4cCI6MjEwNTA1OTQxOH0.D5fE8Jnhod-qtz9xbv4t0_tMtL9YgiVuFLiSdjpAyn0';

  /// يُستدعى مرة واحدة في main() قبل تشغيل التطبيق.
  static Future<void> initialize() async {
    await Supabase.initialize(
      url: projectUrl,
      anonKey: anonKey,
    );
  }
}

/// اختصار سريع للوصول إلى عميل Supabase من أي مكان في التطبيق.
/// مثال: supabase.from('products').select();
final SupabaseClient supabase = Supabase.instance.client;
