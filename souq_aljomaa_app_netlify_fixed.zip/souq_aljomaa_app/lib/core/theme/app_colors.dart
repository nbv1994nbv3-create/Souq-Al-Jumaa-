import 'package:flutter/material.dart';

/// هوية الألوان الخاصة بتطبيق "سوق الجمعة"
/// الأخضر العميق = اللون الأساسي (الثقة، السوق المحلي)
/// الذهبي = لون العروض والتمييز
class AppColors {
  AppColors._();

  // الألوان الأساسية
  static const primary = Color(0xFF1F6F50);
  static const primaryDark = Color(0xFF14503A);
  static const primaryLight = Color(0xFFE7F3EC);

  static const accent = Color(0xFFD4A82F);
  static const accentDark = Color(0xFFA9820F);
  static const accentLight = Color(0xFFFCF3DC);

  // ألوان محايدة
  static const background = Color(0xFFFAFAF8);
  static const surface = Color(0xFFFFFFFF);
  static const textPrimary = Color(0xFF1A1A1A);
  static const textSecondary = Color(0xFF6B6B6B);
  static const border = Color(0xFFE3E1DB);

  // ألوان الحالة
  static const success = Color(0xFF2E7D32);
  static const warning = Color(0xFFED8936);
  static const danger = Color(0xFFD64545);
  static const info = Color(0xFF2F80ED);

  // ألوان حالة الطلب
  static const statusPending = Color(0xFF9E9E9E);
  static const statusConfirmed = Color(0xFF2F80ED);
  static const statusPreparing = Color(0xFFED8936);
  static const statusShipped = Color(0xFF6C4BD1);
  static const statusDelivered = Color(0xFF2E7D32);
  static const statusFailed = Color(0xFFD64545);
}
