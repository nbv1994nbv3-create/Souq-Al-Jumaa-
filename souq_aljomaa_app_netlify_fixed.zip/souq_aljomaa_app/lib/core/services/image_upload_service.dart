import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../network/supabase_config.dart';

/// خدمة موحّدة لاختيار صورة (أو عدّة صور) من معرض الجهاز ورفعها إلى
/// Supabase Storage ضمن مجلد المستخدم الخاص، وإرجاع الرابط العام.
///
/// كل الشاشات التي تحتاج رفع صورة (منتج، شعار متجر، شعار شركة توصيل،
/// صورة شخصية لاحقًا) تستخدم هذه الخدمة بدل التعامل مع Storage مباشرة.
class ImageUploadService {
  final ImagePicker _picker = ImagePicker();

  /// يفتح معرض الصور، يرفع صورة واحدة، ويعيد رابطها العام (أو null
  /// إذا ألغى المستخدم الاختيار).
  Future<String?> pickAndUpload({required String folder, int imageQuality = 80}) async {
    final picked = await _picker.pickImage(source: ImageSource.gallery, imageQuality: imageQuality);
    if (picked == null) return null;
    return _upload(picked, folder);
  }

  /// يفتح معرض الصور بوضع الاختيار المتعدد، يرفع كل صورة، ويعيد قائمة
  /// الروابط العامة بنفس ترتيب الاختيار.
  Future<List<String>> pickAndUploadMultiple({required String folder, int imageQuality = 80}) async {
    final picked = await _picker.pickMultiImage(imageQuality: imageQuality);
    final urls = <String>[];
    for (final file in picked) {
      final url = await _upload(file, folder);
      if (url != null) urls.add(url);
    }
    return urls;
  }

  Future<String?> _upload(XFile file, String folder) async {
    final userId = supabase.auth.currentUser?.id;
    if (userId == null) return null;

    final bytes = await file.readAsBytes();
    final ext = file.name.contains('.') ? file.name.split('.').last : 'jpg';
    final fileName = '${DateTime.now().millisecondsSinceEpoch}.$ext';
    final path = '$folder/$userId/$fileName';

    await supabase.storage.from('uploads').uploadBinary(
          path,
          bytes,
          fileOptions: const FileOptions(upsert: false),
        );

    return supabase.storage.from('uploads').getPublicUrl(path);
  }
}

final imageUploadService = ImageUploadService();
