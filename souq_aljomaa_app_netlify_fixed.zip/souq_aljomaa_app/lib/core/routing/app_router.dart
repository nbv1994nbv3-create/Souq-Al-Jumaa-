import 'dart:async';
import 'package:go_router/go_router.dart';
import 'package:flutter/foundation.dart';
import '../../features/home/presentation/screens/home_screen.dart';
import '../../features/auth/presentation/screens/login_screen.dart';
import '../../features/auth/presentation/screens/otp_verification_screen.dart';
import '../../features/products/presentation/screens/category_products_screen.dart';
import '../../features/products/presentation/screens/offers_screen.dart';
import '../../features/products/presentation/screens/product_details_screen.dart';
import '../../features/cart/presentation/screens/cart_screen.dart';
import '../../features/favorites/presentation/screens/favorites_screen.dart';
import '../../features/checkout/presentation/screens/address_selection_screen.dart';
import '../../features/checkout/presentation/screens/add_address_screen.dart';
import '../../features/checkout/presentation/screens/checkout_delivery_screen.dart';
import '../../features/checkout/presentation/screens/order_confirmation_screen.dart';
import '../../features/orders/presentation/screens/orders_screen.dart';
import '../../features/orders/presentation/screens/order_details_screen.dart';
import '../../features/seller_panel/presentation/screens/seller_dashboard_screen.dart';
import '../../features/seller_panel/presentation/screens/my_products_screen.dart';
import '../../features/seller_panel/presentation/screens/product_form_screen.dart';
import '../../features/seller_panel/presentation/screens/seller_orders_screen.dart';
import '../../features/seller_panel/presentation/screens/sales_report_screen.dart';
import '../../features/delivery_company_panel/presentation/screens/delivery_dashboard_screen.dart';
import '../../features/delivery_company_panel/presentation/screens/coverage_areas_screen.dart';
import '../../features/delivery_company_panel/presentation/screens/delivery_assignments_screen.dart';
import '../../features/admin_panel/presentation/screens/admin_dashboard_screen.dart';
import '../../features/admin_panel/presentation/screens/pending_sellers_screen.dart';
import '../../features/admin_panel/presentation/screens/pending_delivery_companies_screen.dart';
import '../../features/admin_panel/presentation/screens/pending_products_screen.dart';
import '../../features/admin_panel/presentation/screens/complaints_screen.dart';
import '../../features/notifications/presentation/screens/notifications_screen.dart';
import '../network/supabase_config.dart';

/// يحوّل بث حالة المصادقة من Supabase إلى Listenable يفهمه GoRouter،
/// حتى يعيد تقييم شرط redirect تلقائيًا عند تسجيل الدخول/الخروج.
class _AuthRefreshNotifier extends ChangeNotifier {
  _AuthRefreshNotifier() {
    _subscription = supabase.auth.onAuthStateChange.listen((_) => notifyListeners());
  }
  late final StreamSubscription _subscription;

  @override
  void dispose() {
    _subscription.cancel();
    super.dispose();
  }
}

const _publicPaths = ['/login', '/otp'];

/// نقاط التوجيه الرئيسية. كل مجموعة أدوار (زبون/بائع/توصيل/إدارة) لها
/// شجرة مسارات مستقلة تحت بادئة خاصة، ويُحدَّد الدخول إليها بعد تسجيل
/// الدخول بحسب دور المستخدم (role) في الحساب.
///
/// ملاحظة: التوجيه هنا يتحقق فقط من وجود جلسة (تسجيل دخول أم لا).
/// توجيه كل دور إلى لوحته الخاصة (seller/delivery/admin) سيُضاف في
/// خطوة لاحقة بعد بناء ميزة الأقسام/المنتجات، حيث سنقرأ دور
/// المستخدم من currentUserProvider عند أول دخول للشاشة الرئيسية.
final appRouter = GoRouter(
  initialLocation: '/',
  refreshListenable: _AuthRefreshNotifier(),
  redirect: (context, state) {
    final isSignedIn = supabase.auth.currentSession != null;
    final isPublicRoute = _publicPaths.contains(state.matchedLocation);

    if (!isSignedIn && !isPublicRoute) return '/login';
    if (isSignedIn && isPublicRoute) return '/';
    return null;
  },
  routes: [
    // -------- تسجيل الدخول --------
    GoRoute(path: '/login', builder: (context, state) => const LoginScreen()),
    GoRoute(path: '/otp', builder: (context, state) => const OtpVerificationScreen()),

    // -------- مسارات الزبون (customer) --------
    GoRoute(path: '/', builder: (context, state) => const HomeScreen()),
    GoRoute(
      path: '/category/:id',
      builder: (context, state) {
        final id = int.parse(state.pathParameters['id']!);
        final title = state.extra as String?;
        return CategoryProductsScreen(categoryId: id, categoryTitle: title);
      },
    ),
    GoRoute(path: '/offers', builder: (context, state) => const OffersScreen()),
    GoRoute(
      path: '/product/:id',
      builder: (context, state) {
        final id = int.parse(state.pathParameters['id']!);
        return ProductDetailsScreen(productId: id);
      },
    ),
    GoRoute(path: '/cart', builder: (context, state) => const CartScreen()),
    GoRoute(path: '/favorites', builder: (context, state) => const FavoritesScreen()),
    GoRoute(path: '/checkout/address', builder: (context, state) => const AddressSelectionScreen()),
    GoRoute(path: '/checkout/address/new', builder: (context, state) => const AddAddressScreen()),
    GoRoute(path: '/checkout/delivery', builder: (context, state) => const CheckoutDeliveryScreen()),
    GoRoute(
      path: '/orders/:id/confirmation',
      builder: (context, state) {
        final id = int.parse(state.pathParameters['id']!);
        return OrderConfirmationScreen(orderId: id);
      },
    ),
    GoRoute(path: '/orders', builder: (context, state) => const OrdersScreen()),
    GoRoute(
      path: '/orders/:id',
      builder: (context, state) {
        final id = int.parse(state.pathParameters['id']!);
        return OrderDetailsScreen(orderId: id);
      },
    ),
    GoRoute(path: '/profile', builder: (context, state) => const HomeScreen()), // مؤقت

    // -------- مسارات البائع (seller) --------
    GoRoute(path: '/seller', builder: (context, state) => const SellerDashboardScreen()),
    GoRoute(path: '/seller/products', builder: (context, state) => const MyProductsScreen()),
    GoRoute(path: '/seller/products/new', builder: (context, state) => const ProductFormScreen()),
    GoRoute(path: '/seller/orders', builder: (context, state) => const SellerOrdersScreen()),
    GoRoute(path: '/seller/sales-report', builder: (context, state) => const SalesReportScreen()),

    // -------- مسارات شركة التوصيل (delivery_company) --------
    GoRoute(path: '/delivery', builder: (context, state) => const DeliveryDashboardScreen()),
    GoRoute(path: '/delivery/coverage-areas', builder: (context, state) => const CoverageAreasScreen()),
    GoRoute(path: '/delivery/assignments', builder: (context, state) => const DeliveryAssignmentsScreen()),

    // -------- مسارات الإدارة (admin) --------
    GoRoute(path: '/admin', builder: (context, state) => const AdminDashboardScreen()),
    GoRoute(path: '/admin/sellers', builder: (context, state) => const PendingSellersScreen()),
    GoRoute(path: '/admin/delivery-companies', builder: (context, state) => const PendingDeliveryCompaniesScreen()),
    GoRoute(path: '/admin/products', builder: (context, state) => const PendingProductsScreen()),
    GoRoute(path: '/admin/complaints', builder: (context, state) => const ComplaintsScreen()),
    GoRoute(path: '/notifications', builder: (context, state) => const NotificationsScreen()),
  ],
);
