import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'app.dart';
import 'core/network/supabase_config.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SupabaseConfig.initialize();
  // TODO: تهيئة Firebase (الإشعارات) قبل تشغيل التطبيق:
  // await Firebase.initializeApp();
  runApp(const ProviderScope(child: SouqAljomaaApp()));
}
