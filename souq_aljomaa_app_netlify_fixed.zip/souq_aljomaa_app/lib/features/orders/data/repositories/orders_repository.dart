import '../../../../core/network/supabase_config.dart';
import '../models/order_model.dart';

const _orderSelect = '''
  id, status, items_total, shipping_cost, grand_total,
  delivery_otp_code, delivery_otp_verified_at, created_at,
  delivery_company:delivery_companies(company_name),
  address:addresses(governorate, region, label),
  order_items(id, product_id, quantity, unit_price, subtotal,
    product:products(title, product_images(image_url, sort_order)))
''';

class OrdersRepository {
  String get _customerId => supabase.auth.currentUser!.id;

  /// يجلب كل طلبات الزبون الحالي، الأحدث أولاً.
  Future<List<OrderModel>> fetchMyOrders() async {
    final rows = await supabase
        .from('orders')
        .select(_orderSelect)
        .eq('customer_id', _customerId)
        .order('created_at', ascending: false);
    return rows.map((e) => OrderModel.fromJson(e)).toList();
  }

  Future<OrderModel> fetchOrderDetails(int orderId) async {
    final row = await supabase.from('orders').select(_orderSelect).eq('id', orderId).single();
    return OrderModel.fromJson(row);
  }
}

final ordersRepository = OrdersRepository();
