/// عنصر ضمن طلب — يطابق order_items مضمّنًا اسم/صورة المنتج
class OrderItemModel {
  final int id;
  final int productId;
  final String productTitle;
  final String? productImageUrl;
  final int quantity;
  final double unitPrice;
  final double subtotal;

  const OrderItemModel({
    required this.id,
    required this.productId,
    required this.productTitle,
    this.productImageUrl,
    required this.quantity,
    required this.unitPrice,
    required this.subtotal,
  });

  factory OrderItemModel.fromJson(Map<String, dynamic> json) {
    final product = json['product'] as Map<String, dynamic>?;
    final images = (product?['product_images'] as List<dynamic>? ?? [])
        .map((e) => e as Map<String, dynamic>)
        .toList()
      ..sort((a, b) => (a['sort_order'] as int).compareTo(b['sort_order'] as int));

    return OrderItemModel(
      id: json['id'] as int,
      productId: json['product_id'] as int,
      productTitle: product?['title'] as String? ?? '',
      productImageUrl: images.isNotEmpty ? images.first['image_url'] as String : null,
      quantity: json['quantity'] as int,
      unitPrice: (json['unit_price'] as num).toDouble(),
      subtotal: (json['subtotal'] as num).toDouble(),
    );
  }
}

/// حالات الطلب المتاحة — تطابق order_status في قاعدة البيانات، بالترتيب الزمني.
enum OrderStatus {
  pending,
  confirmed,
  preparing,
  assignedToDelivery,
  outForDelivery,
  delivered,
  cancelled;

  static OrderStatus fromDb(String value) {
    switch (value) {
      case 'pending':
        return OrderStatus.pending;
      case 'confirmed':
        return OrderStatus.confirmed;
      case 'preparing':
        return OrderStatus.preparing;
      case 'assigned_to_delivery':
        return OrderStatus.assignedToDelivery;
      case 'out_for_delivery':
        return OrderStatus.outForDelivery;
      case 'delivered':
        return OrderStatus.delivered;
      case 'cancelled':
        return OrderStatus.cancelled;
    }
    throw ArgumentError('حالة طلب غير معروفة: $value');
  }

  String get label => switch (this) {
        OrderStatus.pending => 'قيد الانتظار',
        OrderStatus.confirmed => 'تم التأكيد',
        OrderStatus.preparing => 'قيد التجهيز',
        OrderStatus.assignedToDelivery => 'أُسند لشركة التوصيل',
        OrderStatus.outForDelivery => 'قيد التوصيل',
        OrderStatus.delivered => 'تم التسليم',
        OrderStatus.cancelled => 'ملغى',
      };

  /// ترتيب الحالة ضمن رحلة الطلب الطبيعية (لعرض شريط التقدّم)، يستثني cancelled.
  int get progressIndex => switch (this) {
        OrderStatus.pending => 0,
        OrderStatus.confirmed => 1,
        OrderStatus.preparing => 2,
        OrderStatus.assignedToDelivery => 3,
        OrderStatus.outForDelivery => 4,
        OrderStatus.delivered => 5,
        OrderStatus.cancelled => -1,
      };
}

/// يطابق جدول orders مضمّنًا عناصره وبيانات التوصيل والعنوان.
class OrderModel {
  final int id;
  final OrderStatus status;
  final double itemsTotal;
  final double shippingCost;
  final double grandTotal;
  final String? deliveryOtpCode;
  final DateTime? deliveryOtpVerifiedAt;
  final DateTime createdAt;
  final String? deliveryCompanyName;
  final String addressLabel;
  final List<OrderItemModel> items;

  const OrderModel({
    required this.id,
    required this.status,
    required this.itemsTotal,
    required this.shippingCost,
    required this.grandTotal,
    this.deliveryOtpCode,
    this.deliveryOtpVerifiedAt,
    required this.createdAt,
    this.deliveryCompanyName,
    required this.addressLabel,
    this.items = const [],
  });

  factory OrderModel.fromJson(Map<String, dynamic> json) {
    final address = json['address'] as Map<String, dynamic>?;
    final deliveryCompany = json['delivery_company'] as Map<String, dynamic>?;
    final items = (json['order_items'] as List<dynamic>? ?? [])
        .map((e) => OrderItemModel.fromJson(e as Map<String, dynamic>))
        .toList();

    return OrderModel(
      id: json['id'] as int,
      status: OrderStatus.fromDb(json['status'] as String),
      itemsTotal: (json['items_total'] as num).toDouble(),
      shippingCost: (json['shipping_cost'] as num).toDouble(),
      grandTotal: (json['grand_total'] as num).toDouble(),
      deliveryOtpCode: json['delivery_otp_code'] as String?,
      deliveryOtpVerifiedAt: json['delivery_otp_verified_at'] == null
          ? null
          : DateTime.parse(json['delivery_otp_verified_at'] as String),
      createdAt: DateTime.parse(json['created_at'] as String),
      deliveryCompanyName: deliveryCompany?['company_name'] as String?,
      addressLabel: address == null ? '' : '${address['governorate']} - ${address['region']}',
      items: items,
    );
  }
}
