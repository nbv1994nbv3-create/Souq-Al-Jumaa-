import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/models/order_model.dart';
import '../../data/repositories/orders_repository.dart';

final myOrdersProvider = FutureProvider<List<OrderModel>>((ref) {
  return ordersRepository.fetchMyOrders();
});

final orderDetailsProvider = FutureProvider.family<OrderModel, int>((ref, orderId) {
  return ordersRepository.fetchOrderDetails(orderId);
});
