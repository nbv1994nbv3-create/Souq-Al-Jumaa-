import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../../../core/theme/app_colors.dart';
import '../../data/models/order_model.dart';
import '../providers/orders_provider.dart';

class OrderDetailsScreen extends ConsumerWidget {
  const OrderDetailsScreen({super.key, required this.orderId});
  final int orderId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final orderAsync = ref.watch(orderDetailsProvider(orderId));

    return Scaffold(
      appBar: AppBar(title: Text('طلب #$orderId')),
      body: orderAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('تعذّر تحميل الطلب: $e')),
        data: (order) => RefreshIndicator(
          onRefresh: () async => ref.invalidate(orderDetailsProvider(orderId)),
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              if (order.status != OrderStatus.cancelled) _StatusTimeline(status: order.status),
              if (order.status == OrderStatus.cancelled)
                const _CancelledBanner()
              else
                const SizedBox(height: 20),
              if (order.status == OrderStatus.outForDelivery && order.deliveryOtpCode != null)
                _OtpCard(otp: order.deliveryOtpCode!),
              const SizedBox(height: 8),
              _InfoRow(label: 'عنوان التوصيل', value: order.addressLabel),
              if (order.deliveryCompanyName != null)
                _InfoRow(label: 'شركة التوصيل', value: order.deliveryCompanyName!),
              const Divider(height: 32),
              Text('المنتجات', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              ...order.items.map((item) => _OrderItemTile(item: item)),
              const Divider(height: 32),
              _InfoRow(label: 'إجمالي المنتجات', value: '${order.itemsTotal.toStringAsFixed(0)} د.ع'),
              _InfoRow(label: 'تكلفة التوصيل', value: '${order.shippingCost.toStringAsFixed(0)} د.ع'),
              const SizedBox(height: 4),
              _InfoRow(
                label: 'الإجمالي الكلي',
                value: '${order.grandTotal.toStringAsFixed(0)} د.ع',
                emphasize: true,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatusTimeline extends StatelessWidget {
  const _StatusTimeline({required this.status});
  final OrderStatus status;

  static const _steps = [
    OrderStatus.confirmed,
    OrderStatus.preparing,
    OrderStatus.assignedToDelivery,
    OrderStatus.outForDelivery,
    OrderStatus.delivered,
  ];

  @override
  Widget build(BuildContext context) {
    final currentIndex = status.progressIndex.clamp(0, _steps.length);
    return Row(
      children: List.generate(_steps.length, (i) {
        final isDone = status.progressIndex >= _steps[i].progressIndex;
        return Expanded(
          child: Column(
            children: [
              Row(
                children: [
                  if (i > 0)
                    Expanded(
                      child: Container(
                        height: 2,
                        color: isDone ? AppColors.primary : AppColors.border,
                      ),
                    ),
                  Container(
                    width: 12,
                    height: 12,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: isDone ? AppColors.primary : AppColors.border,
                    ),
                  ),
                  if (i < _steps.length - 1)
                    Expanded(
                      child: Container(
                        height: 2,
                        color: status.progressIndex > _steps[i].progressIndex
                            ? AppColors.primary
                            : AppColors.border,
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                _steps[i].label,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 10,
                  color: isDone ? AppColors.primary : AppColors.textSecondary,
                  fontWeight: isDone ? FontWeight.bold : FontWeight.normal,
                ),
              ),
            ],
          ),
        );
      }),
    );
  }
}

class _CancelledBanner extends StatelessWidget {
  const _CancelledBanner();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.danger.withOpacity(0.1),
        borderRadius: BorderRadius.circular(10),
      ),
      child: const Row(
        children: [
          Icon(Icons.cancel_outlined, color: AppColors.danger),
          SizedBox(width: 8),
          Text('تم إلغاء هذا الطلب', style: TextStyle(color: AppColors.danger, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}

/// بطاقة بارزة تعرض رمز OTP الذي يجب على الزبون إعطاءه لمندوب التوصيل
/// لتأكيد الاستلام (وليس رمز دخول للتطبيق).
class _OtpCard extends StatelessWidget {
  const _OtpCard({required this.otp});
  final String otp;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.primaryLight,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.primary.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          const Text(
            'أعطِ هذا الرمز لمندوب التوصيل لتأكيد استلام طلبك',
            textAlign: TextAlign.center,
            style: TextStyle(color: AppColors.primaryDark, fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 10),
          Text(
            otp,
            style: const TextStyle(
              fontSize: 32,
              fontWeight: FontWeight.bold,
              letterSpacing: 8,
              color: AppColors.primary,
            ),
          ),
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({required this.label, required this.value, this.emphasize = false});
  final String label;
  final String value;
  final bool emphasize;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: AppColors.textSecondary)),
          Text(
            value,
            style: TextStyle(
              fontWeight: emphasize ? FontWeight.bold : FontWeight.w600,
              fontSize: emphasize ? 16 : 14,
              color: emphasize ? AppColors.primary : AppColors.textPrimary,
            ),
          ),
        ],
      ),
    );
  }
}

class _OrderItemTile extends StatelessWidget {
  const _OrderItemTile({required this.item});
  final OrderItemModel item;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: SizedBox(
              width: 56,
              height: 56,
              child: item.productImageUrl != null
                  ? CachedNetworkImage(imageUrl: item.productImageUrl!, fit: BoxFit.cover)
                  : Container(color: AppColors.primaryLight),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item.productTitle, maxLines: 1, overflow: TextOverflow.ellipsis),
                Text('الكمية: ${item.quantity}', style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
              ],
            ),
          ),
          Text('${item.subtotal.toStringAsFixed(0)} د.ع', style: const TextStyle(fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}
