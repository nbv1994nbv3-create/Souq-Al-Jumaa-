import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../../../core/network/supabase_config.dart';
import '../../data/models/notification_model.dart';
import '../../data/repositories/notifications_repository.dart';

class NotificationsState {
  const NotificationsState({this.items = const [], this.isLoading = false});
  final List<NotificationModel> items;
  final bool isLoading;

  int get unreadCount => items.where((n) => !n.isRead).length;

  NotificationsState copyWith({List<NotificationModel>? items, bool? isLoading}) {
    return NotificationsState(items: items ?? this.items, isLoading: isLoading ?? this.isLoading);
  }
}

class NotificationsController extends StateNotifier<NotificationsState> {
  NotificationsController() : super(const NotificationsState()) {
    _init();
  }

  RealtimeChannel? _channel;

  Future<void> _init() async {
    await load();
    _subscribeRealtime();
  }

  Future<void> load() async {
    state = state.copyWith(isLoading: true);
    final items = await notificationsRepository.fetchNotifications();
    state = state.copyWith(items: items, isLoading: false);
  }

  /// يستمع لإشعارات جديدة تصل فورًا (طلب جديد، تحديث حالة...) بدون
  /// الحاجة لتحديث الشاشة يدويًا — يعمل طالما التطبيق مفتوح.
  void _subscribeRealtime() {
    final userId = supabase.auth.currentUser?.id;
    if (userId == null) return;

    _channel = supabase
        .channel('public:notifications:$userId')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'notifications',
          filter: PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: 'user_id', value: userId),
          callback: (payload) {
            final newNotification = NotificationModel.fromJson(payload.newRecord);
            state = state.copyWith(items: [newNotification, ...state.items]);
          },
        )
        .subscribe();
  }

  Future<void> markAsRead(int notificationId) async {
    state = state.copyWith(
      items: [
        for (final n in state.items)
          if (n.id == notificationId)
            NotificationModel(
              id: n.id, title: n.title, body: n.body, type: n.type,
              relatedOrderId: n.relatedOrderId, isRead: true, createdAt: n.createdAt,
            )
          else
            n,
      ],
    );
    await notificationsRepository.markAsRead(notificationId);
  }

  Future<void> markAllAsRead() async {
    await notificationsRepository.markAllAsRead();
    await load();
  }

  @override
  void dispose() {
    if (_channel != null) supabase.removeChannel(_channel!);
    super.dispose();
  }
}

final notificationsProvider = StateNotifierProvider<NotificationsController, NotificationsState>((ref) {
  return NotificationsController();
});
