import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/theme/app_colors.dart';
import '../../data/models/notification_model.dart';
import '../providers/notifications_provider.dart';

IconData _iconFor(IconIdentifier type) => switch (type) {
      IconIdentifier.order => Icons.receipt_long_outlined,
      IconIdentifier.delivery => Icons.local_shipping_outlined,
      IconIdentifier.approval => Icons.verified_outlined,
      IconIdentifier.product => Icons.inventory_2_outlined,
      IconIdentifier.complaint => Icons.report_gmailerrorred_outlined,
      IconIdentifier.general => Icons.notifications_outlined,
    };

String _timeAgo(DateTime dateTime) {
  final diff = DateTime.now().difference(dateTime);
  if (diff.inMinutes < 1) return 'الآن';
  if (diff.inMinutes < 60) return 'منذ ${diff.inMinutes} دقيقة';
  if (diff.inHours < 24) return 'منذ ${diff.inHours} ساعة';
  return 'منذ ${diff.inDays} يوم';
}

class NotificationsScreen extends ConsumerWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(notificationsProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('الإشعارات'),
        actions: [
          if (state.unreadCount > 0)
            TextButton(
              onPressed: () => ref.read(notificationsProvider.notifier).markAllAsRead(),
              child: const Text('تعليم الكل كمقروء'),
            ),
        ],
      ),
      body: state.isLoading && state.items.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : state.items.isEmpty
              ? const Center(child: Text('لا توجد إشعارات بعد'))
              : RefreshIndicator(
                  onRefresh: () => ref.read(notificationsProvider.notifier).load(),
                  child: ListView.separated(
                    itemCount: state.items.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (context, i) => _NotificationTile(notification: state.items[i]),
                  ),
                ),
    );
  }
}

class _NotificationTile extends ConsumerWidget {
  const _NotificationTile({required this.notification});
  final NotificationModel notification;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ListTile(
      tileColor: notification.isRead ? null : AppColors.primaryLight.withOpacity(0.4),
      leading: CircleAvatar(
        backgroundColor: AppColors.primaryLight,
        child: Icon(_iconFor(notification.iconType), color: AppColors.primary, size: 20),
      ),
      title: Text(notification.title, style: const TextStyle(fontWeight: FontWeight.w600)),
      subtitle: notification.body != null ? Text(notification.body!) : null,
      trailing: Text(_timeAgo(notification.createdAt), style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
      onTap: () {
        if (!notification.isRead) ref.read(notificationsProvider.notifier).markAsRead(notification.id);
        if (notification.relatedOrderId != null) {
          context.push('/orders/${notification.relatedOrderId}');
        }
      },
    );
  }
}
