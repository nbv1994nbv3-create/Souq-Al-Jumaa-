/// يطابق جدول notifications
class NotificationModel {
  final int id;
  final String title;
  final String? body;
  final String type;
  final int? relatedOrderId;
  final bool isRead;
  final DateTime createdAt;

  const NotificationModel({
    required this.id,
    required this.title,
    this.body,
    required this.type,
    this.relatedOrderId,
    required this.isRead,
    required this.createdAt,
  });

  factory NotificationModel.fromJson(Map<String, dynamic> json) {
    return NotificationModel(
      id: json['id'] as int,
      title: json['title'] as String,
      body: json['body'] as String?,
      type: json['type'] as String,
      relatedOrderId: json['related_order_id'] as int?,
      isRead: json['is_read'] as bool? ?? false,
      createdAt: DateTime.parse(json['created_at'] as String),
    );
  }

  IconIdentifier get iconType => switch (type) {
        'order_status' => IconIdentifier.order,
        'new_order' => IconIdentifier.order,
        'new_assignment' => IconIdentifier.delivery,
        'approval' => IconIdentifier.approval,
        'product_moderation' => IconIdentifier.product,
        'complaint' => IconIdentifier.complaint,
        _ => IconIdentifier.general,
      };
}

enum IconIdentifier { order, delivery, approval, product, complaint, general }
