import '../../../../core/network/supabase_config.dart';
import '../models/notification_model.dart';

class NotificationsRepository {
  String get _userId => supabase.auth.currentUser!.id;

  Future<List<NotificationModel>> fetchNotifications() async {
    final rows = await supabase
        .from('notifications')
        .select()
        .eq('user_id', _userId)
        .order('created_at', ascending: false)
        .limit(50);
    return rows.map((e) => NotificationModel.fromJson(e)).toList();
  }

  Future<void> markAsRead(int notificationId) async {
    await supabase.from('notifications').update({'is_read': true}).eq('id', notificationId);
  }

  Future<void> markAllAsRead() async {
    await supabase.from('notifications').update({'is_read': true}).eq('user_id', _userId).eq('is_read', false);
  }
}

final notificationsRepository = NotificationsRepository();
