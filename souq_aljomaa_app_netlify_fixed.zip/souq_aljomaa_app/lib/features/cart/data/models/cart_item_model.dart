import '../../../products/data/models/product_model.dart';

/// يطابق صف cart_items مضمّنًا بيانات المنتج الكاملة.
class CartItemModel {
  final int id; // معرّف صف cart_items نفسه
  final ProductModel product;
  final int quantity;

  const CartItemModel({
    required this.id,
    required this.product,
    required this.quantity,
  });

  double get subtotal => product.displayPrice * quantity;

  factory CartItemModel.fromJson(Map<String, dynamic> json) {
    return CartItemModel(
      id: json['id'] as int,
      quantity: json['quantity'] as int,
      product: ProductModel.fromJson(json['product'] as Map<String, dynamic>),
    );
  }
}
