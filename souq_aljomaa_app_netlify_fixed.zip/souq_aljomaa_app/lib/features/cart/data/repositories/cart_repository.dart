import '../../../../core/network/supabase_config.dart';
import '../../../products/data/repositories/products_repository.dart';
import '../models/cart_item_model.dart';

class CartRepository {
  String get _customerId => supabase.auth.currentUser!.id;

  /// يجلب كل عناصر سلة المستخدم الحالي مع بيانات المنتج الكاملة.
  Future<List<CartItemModel>> fetchCart() async {
    final rows = await supabase
        .from('cart_items')
        .select('id, quantity, added_at, product:products($productSelectFragment)')
        .eq('customer_id', _customerId)
        .order('added_at', ascending: false);
    return rows.map((e) => CartItemModel.fromJson(e)).toList();
  }

  /// يضيف منتجًا للسلة، أو يزيد كميته إذا كان موجودًا مسبقًا (upsert).
  Future<void> addToCart(int productId, {int quantity = 1}) async {
    final existing = await supabase
        .from('cart_items')
        .select('id, quantity')
        .eq('customer_id', _customerId)
        .eq('product_id', productId)
        .maybeSingle();

    if (existing == null) {
      await supabase.from('cart_items').insert({
        'customer_id': _customerId,
        'product_id': productId,
        'quantity': quantity,
      });
    } else {
      await supabase
          .from('cart_items')
          .update({'quantity': (existing['quantity'] as int) + quantity})
          .eq('id', existing['id'] as int);
    }
  }

  /// يحدّث كمية عنصر سلة محدد مباشرة (لا يزيدها، يستبدلها).
  Future<void> updateQuantity(int cartItemId, int quantity) async {
    await supabase.from('cart_items').update({'quantity': quantity}).eq('id', cartItemId);
  }

  Future<void> removeItem(int cartItemId) async {
    await supabase.from('cart_items').delete().eq('id', cartItemId);
  }

  /// يفرّغ السلة بالكامل (يُستخدم بعد إتمام الطلب).
  Future<void> clearCart() async {
    await supabase.from('cart_items').delete().eq('customer_id', _customerId);
  }
}

final cartRepository = CartRepository();
