import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/models/cart_item_model.dart';
import '../../data/repositories/cart_repository.dart';

class CartState {
  const CartState({this.items = const [], this.isLoading = false, this.errorMessage});

  final List<CartItemModel> items;
  final bool isLoading;
  final String? errorMessage;

  int get itemsCount => items.fold(0, (sum, item) => sum + item.quantity);
  double get total => items.fold(0, (sum, item) => sum + item.subtotal);

  CartState copyWith({List<CartItemModel>? items, bool? isLoading, String? errorMessage}) {
    return CartState(
      items: items ?? this.items,
      isLoading: isLoading ?? this.isLoading,
      errorMessage: errorMessage,
    );
  }
}

class CartController extends StateNotifier<CartState> {
  CartController() : super(const CartState()) {
    loadCart();
  }

  Future<void> loadCart() async {
    state = state.copyWith(isLoading: true, errorMessage: null);
    try {
      final items = await cartRepository.fetchCart();
      state = state.copyWith(items: items, isLoading: false);
    } catch (e) {
      state = state.copyWith(isLoading: false, errorMessage: e.toString());
    }
  }

  Future<void> addToCart(int productId) async {
    await cartRepository.addToCart(productId);
    await loadCart();
  }

  /// تحديث فوري بالواجهة قبل انتظار رد الخادم، مع تراجع عند الفشل.
  Future<void> updateQuantity(CartItemModel item, int newQuantity) async {
    if (newQuantity < 1) return removeItem(item);
    final previous = state.items;
    state = state.copyWith(
      items: [
        for (final i in state.items)
          if (i.id == item.id) CartItemModel(id: i.id, product: i.product, quantity: newQuantity) else i,
      ],
    );
    try {
      await cartRepository.updateQuantity(item.id, newQuantity);
    } catch (e) {
      state = state.copyWith(items: previous, errorMessage: e.toString());
    }
  }

  Future<void> removeItem(CartItemModel item) async {
    final previous = state.items;
    state = state.copyWith(items: state.items.where((i) => i.id != item.id).toList());
    try {
      await cartRepository.removeItem(item.id);
    } catch (e) {
      state = state.copyWith(items: previous, errorMessage: e.toString());
    }
  }

  Future<void> clearCart() async {
    final previous = state.items;
    state = state.copyWith(items: []);
    try {
      await cartRepository.clearCart();
    } catch (e) {
      state = state.copyWith(items: previous, errorMessage: e.toString());
    }
  }
}

final cartProvider = StateNotifierProvider<CartController, CartState>((ref) {
  return CartController();
});
