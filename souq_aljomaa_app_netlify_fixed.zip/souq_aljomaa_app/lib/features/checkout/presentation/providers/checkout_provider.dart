import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/models/address_model.dart';
import '../../data/models/delivery_option_model.dart';
import '../../data/repositories/addresses_repository.dart';
import '../../data/repositories/checkout_repository.dart';

/// قائمة عناوين المستخدم الحالي.
final addressesProvider = FutureProvider<List<AddressModel>>((ref) {
  return addressesRepository.fetchAddresses();
});

/// العنوان المختار حاليًا لإتمام الطلب (يُضبط عند دخول شاشة الدفع).
final selectedAddressProvider = StateProvider<AddressModel?>((ref) => null);

/// خيارات التوصيل المتاحة للعنوان المختار.
final deliveryOptionsProvider = FutureProvider<List<DeliveryOptionModel>>((ref) {
  final address = ref.watch(selectedAddressProvider);
  if (address == null) return Future.value(const []);
  return checkoutRepository.fetchDeliveryOptions(
    governorate: address.governorate,
    region: address.region,
  );
});

/// حالة تنفيذ إنشاء الطلب (تحميل/خطأ/نجاح مع رقم الطلب).
class CreateOrderState {
  const CreateOrderState({this.isLoading = false, this.errorMessage, this.orderId});
  final bool isLoading;
  final String? errorMessage;
  final int? orderId;

  CreateOrderState copyWith({bool? isLoading, String? errorMessage, int? orderId}) {
    return CreateOrderState(
      isLoading: isLoading ?? this.isLoading,
      errorMessage: errorMessage,
      orderId: orderId ?? this.orderId,
    );
  }
}

class CreateOrderController extends StateNotifier<CreateOrderState> {
  CreateOrderController() : super(const CreateOrderState());

  Future<void> submit({
    required int addressId,
    required String deliveryCompanyId,
    required double shippingCost,
  }) async {
    state = state.copyWith(isLoading: true, errorMessage: null);
    try {
      final orderId = await checkoutRepository.createOrder(
        addressId: addressId,
        deliveryCompanyId: deliveryCompanyId,
        shippingCost: shippingCost,
      );
      state = state.copyWith(isLoading: false, orderId: orderId);
    } catch (e) {
      state = state.copyWith(isLoading: false, errorMessage: e.toString());
    }
  }
}

final createOrderProvider = StateNotifierProvider<CreateOrderController, CreateOrderState>((ref) {
  return CreateOrderController();
});
