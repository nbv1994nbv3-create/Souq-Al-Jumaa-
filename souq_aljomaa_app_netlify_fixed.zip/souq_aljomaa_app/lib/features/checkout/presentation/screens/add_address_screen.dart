import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/theme/app_colors.dart';
import '../../data/models/address_model.dart';
import '../../data/repositories/addresses_repository.dart';
import '../providers/checkout_provider.dart';

class AddAddressScreen extends ConsumerStatefulWidget {
  const AddAddressScreen({super.key});

  @override
  ConsumerState<AddAddressScreen> createState() => _AddAddressScreenState();
}

class _AddAddressScreenState extends ConsumerState<AddAddressScreen> {
  final _formKey = GlobalKey<FormState>();
  final _labelController = TextEditingController();
  final _detailsController = TextEditingController();
  String? _governorate;
  final _regionController = TextEditingController();
  bool _isDefault = false;
  bool _isSaving = false;

  @override
  void dispose() {
    _labelController.dispose();
    _detailsController.dispose();
    _regionController.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate() || _governorate == null) return;
    setState(() => _isSaving = true);
    try {
      await addressesRepository.addAddress(
        label: _labelController.text.trim().isEmpty ? null : _labelController.text.trim(),
        governorate: _governorate!,
        region: _regionController.text.trim(),
        detailsText: _detailsController.text.trim().isEmpty ? null : _detailsController.text.trim(),
        isDefault: _isDefault,
      );
      ref.invalidate(addressesProvider);
      if (mounted) context.pop();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذّر حفظ العنوان: $e')));
      }
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('عنوان جديد')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(
              controller: _labelController,
              decoration: const InputDecoration(labelText: 'اسم العنوان (اختياري)', hintText: 'المنزل، العمل...'),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              initialValue: _governorate,
              decoration: const InputDecoration(labelText: 'المحافظة', border: OutlineInputBorder()),
              items: iraqGovernorates
                  .map((g) => DropdownMenuItem(value: g, child: Text(g)))
                  .toList(),
              onChanged: (value) => setState(() => _governorate = value),
              validator: (value) => value == null ? 'اختر المحافظة' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _regionController,
              decoration: const InputDecoration(labelText: 'المنطقة / الحي', border: OutlineInputBorder()),
              validator: (v) => (v == null || v.trim().isEmpty) ? 'أدخل اسم المنطقة' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _detailsController,
              maxLines: 2,
              decoration: const InputDecoration(
                labelText: 'تفاصيل إضافية (اختياري)',
                hintText: 'أقرب نقطة دالة، رقم البناء...',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 8),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('اجعله العنوان الافتراضي'),
              value: _isDefault,
              onChanged: (v) => setState(() => _isDefault = v),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _isSaving ? null : _save,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              child: _isSaving
                  ? const SizedBox(
                      width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Text('حفظ العنوان'),
            ),
          ],
        ),
      ),
    );
  }
}
