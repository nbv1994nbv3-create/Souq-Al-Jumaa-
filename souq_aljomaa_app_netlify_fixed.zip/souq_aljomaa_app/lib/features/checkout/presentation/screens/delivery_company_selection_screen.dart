import 'package:flutter/material.dart';
import '../../../../core/theme/app_colors.dart';
import '../../data/models/delivery_option_model.dart';

/// شاشة اختيار شركة التوصيل بعد تحديد الزبون لعنوانه.
/// تعرض الشركات المتاحة لمنطقة العنوان مع تكلفة الشحن، المدة، نوع الخدمة،
/// والتقييم — ويمكن ترتيبها حسب: الأقل تكلفة / الأسرع / الأعلى تقييمًا.
class DeliveryCompanySelectionScreen extends StatefulWidget {
  final List<DeliveryOptionModel> options;
  final void Function(DeliveryOptionModel selected) onConfirm;

  const DeliveryCompanySelectionScreen({
    super.key,
    required this.options,
    required this.onConfirm,
  });

  @override
  State<DeliveryCompanySelectionScreen> createState() => _DeliveryCompanySelectionScreenState();
}

class _DeliveryCompanySelectionScreenState extends State<DeliveryCompanySelectionScreen> {
  DeliverySortOption _sort = DeliverySortOption.lowestCost;
  String? _selectedId;

  List<DeliveryOptionModel> get _sortedOptions {
    final list = [...widget.options];
    switch (_sort) {
      case DeliverySortOption.lowestCost:
        list.sort((a, b) => a.shippingCost.compareTo(b.shippingCost));
      case DeliverySortOption.fastest:
        list.sort((a, b) => a.expectedDurationHours.compareTo(b.expectedDurationHours));
      case DeliverySortOption.highestRated:
        list.sort((a, b) => b.ratingAvg.compareTo(a.ratingAvg));
    }
    return list;
  }

  @override
  Widget build(BuildContext context) {
    final options = _sortedOptions;

    return Scaffold(
      appBar: AppBar(title: const Text('اختيار شركة التوصيل')),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _buildSortBar(),
          Expanded(
            child: options.isEmpty
                ? const Center(child: Text('لا توجد شركات توصيل تغطي هذا العنوان حاليًا'))
                : ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: options.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 12),
                    itemBuilder: (context, i) => _DeliveryOptionCard(
                      option: options[i],
                      isSelected: _selectedId == options[i].deliveryCompanyId,
                      onSelect: () => setState(() => _selectedId = options[i].deliveryCompanyId),
                    ),
                  ),
          ),
          _buildConfirmButton(options),
        ],
      ),
    );
  }

  Widget _buildSortBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          const Text('ترتيب حسب:', style: TextStyle(color: AppColors.textSecondary, fontSize: 13)),
          const SizedBox(width: 8),
          Expanded(
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _sortChip('الأقل تكلفة', DeliverySortOption.lowestCost),
                  const SizedBox(width: 8),
                  _sortChip('الأسرع توصيلًا', DeliverySortOption.fastest),
                  const SizedBox(width: 8),
                  _sortChip('الأعلى تقييمًا', DeliverySortOption.highestRated),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sortChip(String label, DeliverySortOption value) {
    final selected = _sort == value;
    return ChoiceChip(
      label: Text(label),
      selected: selected,
      onSelected: (_) => setState(() => _sort = value),
    );
  }

  Widget _buildConfirmButton(List<DeliveryOptionModel> options) {
    DeliveryOptionModel? selected;
    for (final o in options) {
      if (o.deliveryCompanyId == _selectedId) {
        selected = o;
        break;
      }
    }
    return SafeArea(
      minimum: const EdgeInsets.all(16),
      child: ElevatedButton(
        onPressed: selected == null ? null : () => widget.onConfirm(selected),
        child: const Text('تأكيد اختيار شركة التوصيل'),
      ),
    );
  }
}

class _DeliveryOptionCard extends StatelessWidget {
  final DeliveryOptionModel option;
  final bool isSelected;
  final VoidCallback onSelect;

  const _DeliveryOptionCard({
    required this.option,
    required this.isSelected,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onSelect,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isSelected ? AppColors.primary : AppColors.border,
            width: isSelected ? 1.5 : 1,
          ),
        ),
        child: Row(
          children: [
            CircleAvatar(
              radius: 22,
              backgroundColor: AppColors.primaryLight,
              backgroundImage: option.logoUrl != null ? NetworkImage(option.logoUrl!) : null,
              child: option.logoUrl == null
                  ? Text(option.companyName.substring(0, 1), style: const TextStyle(color: AppColors.primary))
                  : null,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(option.companyName,
                            style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                      ),
                      if (option.isExpress) _badge('سريع', AppColors.accent, AppColors.accentDark),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Text('${option.shippingCost.toStringAsFixed(0)} دينار',
                          style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.primary)),
                      const SizedBox(width: 10),
                      const Icon(Icons.timer_outlined, size: 14, color: AppColors.textSecondary),
                      const SizedBox(width: 2),
                      Text(option.durationLabel, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      const Icon(Icons.star, size: 14, color: AppColors.accent),
                      const SizedBox(width: 2),
                      Text(option.ratingAvg.toStringAsFixed(1),
                          style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                      Text(' (${option.ratingCount})',
                          style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                    ],
                  ),
                ],
              ),
            ),
            Radio<bool>(
              value: true,
              groupValue: isSelected ? true : null,
              onChanged: (_) => onSelect(),
              activeColor: AppColors.primary,
            ),
          ],
        ),
      ),
    );
  }

  Widget _badge(String label, Color bg, Color fg) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(color: bg.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(20)),
      child: Text(label, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: fg)),
    );
  }
}
