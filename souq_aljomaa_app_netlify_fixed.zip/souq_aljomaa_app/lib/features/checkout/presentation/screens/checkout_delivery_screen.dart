import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../cart/presentation/providers/cart_provider.dart';
import '../providers/checkout_provider.dart';
import 'delivery_company_selection_screen.dart';

/// يربط [DeliveryCompanySelectionScreen] الجاهزة بمصدر بيانات حقيقي
/// (مناطق تغطية شركات التوصيل لعنوان الزبون المختار)، وعند التأكيد
/// ينشئ الطلب فعليًا في قاعدة البيانات.
class CheckoutDeliveryScreen extends ConsumerWidget {
  const CheckoutDeliveryScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final address = ref.watch(selectedAddressProvider);
    final optionsAsync = ref.watch(deliveryOptionsProvider);
    final orderState = ref.watch(createOrderProvider);

    ref.listen(createOrderProvider, (previous, next) {
      if (next.orderId != null && previous?.orderId != next.orderId) {
        // فرّغ حالة السلة المحلية فورًا (فُرّغت فعليًا بقاعدة البيانات ضمن create_order)
        ref.invalidate(cartProvider);
        context.go('/orders/${next.orderId}/confirmation');
      }
      if (next.errorMessage != null && next.errorMessage != previous?.errorMessage) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(next.errorMessage!)));
      }
    });

    if (address == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('اختيار شركة التوصيل')),
        body: const Center(child: Text('اختر عنوانًا أولاً')),
      );
    }

    return Stack(
      children: [
        optionsAsync.when(
          loading: () => const Scaffold(body: Center(child: CircularProgressIndicator())),
          error: (e, _) => Scaffold(body: Center(child: Text('تعذّر تحميل شركات التوصيل: $e'))),
          data: (options) => DeliveryCompanySelectionScreen(
            options: options,
            onConfirm: (selected) => ref.read(createOrderProvider.notifier).submit(
                  addressId: address.id,
                  deliveryCompanyId: selected.deliveryCompanyId,
                  shippingCost: selected.shippingCost,
                ),
          ),
        ),
        if (orderState.isLoading)
          Container(
            color: Colors.black26,
            child: const Center(child: CircularProgressIndicator()),
          ),
      ],
    );
  }
}
