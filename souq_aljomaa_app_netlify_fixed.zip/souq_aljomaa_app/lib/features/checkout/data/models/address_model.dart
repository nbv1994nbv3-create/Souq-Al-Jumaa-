/// يطابق جدول addresses في قاعدة البيانات
class AddressModel {
  final int id;
  final String? label;
  final String governorate;
  final String region;
  final String? detailsText;
  final bool isDefault;

  const AddressModel({
    required this.id,
    this.label,
    required this.governorate,
    required this.region,
    this.detailsText,
    this.isDefault = false,
  });

  factory AddressModel.fromJson(Map<String, dynamic> json) {
    return AddressModel(
      id: json['id'] as int,
      label: json['label'] as String?,
      governorate: json['governorate'] as String,
      region: json['region'] as String,
      detailsText: json['details_text'] as String?,
      isDefault: json['is_default'] as bool? ?? false,
    );
  }

  String get shortAddress => '$governorate - $region';
}

/// محافظات العراق الثمانية عشر — تُستخدم بقائمة اختيار العنوان.
const iraqGovernorates = [
  'بغداد', 'البصرة', 'نينوى', 'أربيل', 'النجف', 'كربلاء',
  'الأنبار', 'ذي قار', 'ديالى', 'كركوك', 'بابل', 'واسط',
  'صلاح الدين', 'ميسان', 'المثنى', 'القادسية', 'دهوك', 'السليمانية',
];
