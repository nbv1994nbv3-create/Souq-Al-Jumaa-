/// خيار توصيل مُتاح لعنوان الزبون — ناتج عن مطابقة delivery_coverage_areas
/// مع عنوان الزبون المُختار (المحافظة/المنطقة)، كما هو موضّح في وثيقة المتطلبات.
class DeliveryOptionModel {
  final String deliveryCompanyId; // uuid
  final String companyName;
  final String? logoUrl;
  final double shippingCost;
  final int expectedDurationHours;
  final String shippingType; // 'normal' | 'express'
  final double ratingAvg;
  final int ratingCount;

  const DeliveryOptionModel({
    required this.deliveryCompanyId,
    required this.companyName,
    this.logoUrl,
    required this.shippingCost,
    required this.expectedDurationHours,
    required this.shippingType,
    required this.ratingAvg,
    required this.ratingCount,
  });

  /// يبني الخيار من استعلام delivery_coverage_areas مضمّنًا بيانات الشركة:
  /// select('*, company:delivery_companies(company_name, logo_url, rating_avg, rating_count)')
  factory DeliveryOptionModel.fromJson(Map<String, dynamic> json) {
    final company = json['company'] as Map<String, dynamic>;
    return DeliveryOptionModel(
      deliveryCompanyId: json['delivery_company_id'] as String,
      companyName: company['company_name'] as String,
      logoUrl: company['logo_url'] as String?,
      shippingCost: (json['shipping_cost'] as num).toDouble(),
      expectedDurationHours: json['expected_duration_hours'] as int,
      shippingType: json['shipping_type'] as String,
      ratingAvg: (company['rating_avg'] as num).toDouble(),
      ratingCount: company['rating_count'] as int,
    );
  }

  String get durationLabel {
    if (expectedDurationHours <= 24) return 'خلال 24 ساعة';
    final days = (expectedDurationHours / 24).ceil();
    return 'خلال $days ${days == 1 ? 'يوم' : 'أيام'}';
  }

  bool get isExpress => shippingType == 'express';
}

enum DeliverySortOption { lowestCost, fastest, highestRated }
