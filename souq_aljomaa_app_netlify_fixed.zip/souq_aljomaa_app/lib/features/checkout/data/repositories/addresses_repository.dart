import '../../../../core/network/supabase_config.dart';
import '../models/address_model.dart';

class AddressesRepository {
  String get _customerId => supabase.auth.currentUser!.id;

  Future<List<AddressModel>> fetchAddresses() async {
    final rows = await supabase
        .from('addresses')
        .select()
        .eq('customer_id', _customerId)
        .order('is_default', ascending: false)
        .order('created_at', ascending: false);
    return rows.map((e) => AddressModel.fromJson(e)).toList();
  }

  Future<AddressModel> addAddress({
    String? label,
    required String governorate,
    required String region,
    String? detailsText,
    bool isDefault = false,
  }) async {
    // إذا اختار المستخدم هذا العنوان كافتراضي، ألغِ الافتراضي عن البقية أولاً
    // (فهرس فريد جزئي بقاعدة البيانات يمنع أكثر من عنوان افتراضي واحد).
    if (isDefault) await _clearDefault();

    final row = await supabase
        .from('addresses')
        .insert({
          'customer_id': _customerId,
          'label': label,
          'governorate': governorate,
          'region': region,
          'details_text': detailsText,
          'is_default': isDefault,
        })
        .select()
        .single();
    return AddressModel.fromJson(row);
  }

  Future<void> setDefault(int addressId) async {
    await _clearDefault();
    await supabase.from('addresses').update({'is_default': true}).eq('id', addressId);
  }

  Future<void> _clearDefault() async {
    await supabase
        .from('addresses')
        .update({'is_default': false})
        .eq('customer_id', _customerId)
        .eq('is_default', true);
  }

  Future<void> deleteAddress(int addressId) async {
    await supabase.from('addresses').delete().eq('id', addressId);
  }
}

final addressesRepository = AddressesRepository();
