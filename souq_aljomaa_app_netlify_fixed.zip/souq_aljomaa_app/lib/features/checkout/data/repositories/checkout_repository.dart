import '../../../../core/network/supabase_config.dart';
import '../models/delivery_option_model.dart';

class CheckoutRepository {
  /// يجلب كل شركات التوصيل التي تغطي محافظة/منطقة عنوان الزبون.
  Future<List<DeliveryOptionModel>> fetchDeliveryOptions({
    required String governorate,
    required String region,
  }) async {
    final rows = await supabase
        .from('delivery_coverage_areas')
        .select('''
          delivery_company_id, shipping_cost, expected_duration_hours, shipping_type,
          company:delivery_companies(company_name, logo_url, rating_avg, rating_count)
        ''')
        .eq('governorate', governorate)
        .eq('region', region)
        .eq('is_active', true);
    return rows.map((e) => DeliveryOptionModel.fromJson(e)).toList();
  }

  /// ينشئ الطلب من محتويات السلة الحالية عبر دالة قاعدة بيانات ذرية،
  /// ويعيد معرّف الطلب الجديد.
  Future<int> createOrder({
    required int addressId,
    required String deliveryCompanyId,
    required double shippingCost,
  }) async {
    final orderId = await supabase.rpc('create_order', params: {
      'p_address_id': addressId,
      'p_delivery_company_id': deliveryCompanyId,
      'p_shipping_cost': shippingCost,
    });
    return orderId as int;
  }
}

final checkoutRepository = CheckoutRepository();
