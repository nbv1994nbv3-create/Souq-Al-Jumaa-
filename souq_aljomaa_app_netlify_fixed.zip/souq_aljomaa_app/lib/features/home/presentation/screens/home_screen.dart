import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../products/data/models/category_model.dart';
import '../../../products/presentation/providers/products_provider.dart';
import '../../../cart/presentation/providers/cart_provider.dart';
import '../../../notifications/presentation/providers/notifications_provider.dart';

/// يربط كل slug قسم بأيقونة مناسبة (الأيقونات فقط للعرض، مو من قاعدة البيانات).
IconData _iconForSlug(String slug) {
  switch (slug) {
    case 'real_estate':
      return Icons.home_work_outlined;
    case 'phones':
      return Icons.phone_iphone_outlined;
    case 'generators':
      return Icons.electrical_services_outlined;
    case 'electronics':
      return Icons.tv_outlined;
    case 'clothing':
      return Icons.checkroom_outlined;
    case 'furniture':
      return Icons.chair_outlined;
    case 'appliances':
      return Icons.kitchen_outlined;
    case 'accessories':
      return Icons.watch_outlined;
    default:
      return Icons.category_outlined;
  }
}

/// الشاشة الرئيسية — تعرض أقسام التطبيق من قاعدة البيانات + بلاطة العروض.
class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final categoriesAsync = ref.watch(categoriesProvider);
    final cartCount = ref.watch(cartProvider).itemsCount;
    final unreadNotifications = ref.watch(notificationsProvider).unreadCount;

    return Scaffold(
      appBar: AppBar(
        title: const Text('سوق الجمعة'),
        actions: [
          Stack(
            alignment: Alignment.center,
            children: [
              IconButton(
                icon: const Icon(Icons.notifications_outlined),
                tooltip: 'الإشعارات',
                onPressed: () => context.push('/notifications'),
              ),
              if (unreadNotifications > 0)
                Positioned(
                  top: 6,
                  right: 6,
                  child: Container(
                    padding: const EdgeInsets.all(3),
                    decoration: const BoxDecoration(color: AppColors.danger, shape: BoxShape.circle),
                    constraints: const BoxConstraints(minWidth: 16, minHeight: 16),
                    child: Text(
                      '$unreadNotifications',
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.white, fontSize: 10),
                    ),
                  ),
                ),
            ],
          ),
          IconButton(
            icon: const Icon(Icons.admin_panel_settings_outlined),
            tooltip: 'لوحة الإدارة',
            onPressed: () => context.push('/admin'),
          ),
          IconButton(
            icon: const Icon(Icons.local_shipping_outlined),
            tooltip: 'لوحة شركة التوصيل',
            onPressed: () => context.push('/delivery'),
          ),
          IconButton(
            icon: const Icon(Icons.storefront_outlined),
            tooltip: 'لوحة البائع',
            onPressed: () => context.push('/seller'),
          ),
          IconButton(
            icon: const Icon(Icons.favorite_border),
            onPressed: () => context.push('/favorites'),
          ),
          Stack(
            alignment: Alignment.center,
            children: [
              IconButton(
                icon: const Icon(Icons.shopping_cart_outlined),
                onPressed: () => context.push('/cart'),
              ),
              if (cartCount > 0)
                Positioned(
                  top: 6,
                  right: 6,
                  child: Container(
                    padding: const EdgeInsets.all(3),
                    decoration: const BoxDecoration(color: AppColors.danger, shape: BoxShape.circle),
                    constraints: const BoxConstraints(minWidth: 16, minHeight: 16),
                    child: Text(
                      '$cartCount',
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.white, fontSize: 10),
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: categoriesAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, _) => Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text('تعذّر تحميل الأقسام: $error', textAlign: TextAlign.center),
          ),
        ),
        data: (categories) => RefreshIndicator(
          onRefresh: () async => ref.invalidate(categoriesProvider),
          child: GridView.builder(
            padding: const EdgeInsets.all(16),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 0.9,
            ),
            // +1 لبلاطة "العروض" المضافة يدويًا بنهاية الشبكة
            itemCount: categories.length + 1,
            itemBuilder: (context, i) {
              final isOfferTile = i == categories.length;
              if (isOfferTile) {
                return _SectionTile(
                  title: 'العروض والمنتجات المخفضة',
                  icon: Icons.local_offer_outlined,
                  isOffer: true,
                  onTap: () => context.push('/offers'),
                );
              }
              final CategoryModel category = categories[i];
              return _SectionTile(
                title: category.name,
                icon: _iconForSlug(category.slug),
                isOffer: false,
                onTap: () => context.push('/category/${category.id}', extra: category.name),
              );
            },
          ),
        ),
      ),
    );
  }
}

class _SectionTile extends StatelessWidget {
  const _SectionTile({
    required this.title,
    required this.icon,
    required this.isOffer,
    required this.onTap,
  });

  final String title;
  final IconData icon;
  final bool isOffer;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: isOffer ? AppColors.accentLight : AppColors.primaryLight,
          borderRadius: BorderRadius.circular(14),
        ),
        padding: const EdgeInsets.all(10),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: isOffer ? AppColors.accentDark : AppColors.primary, size: 28),
            const SizedBox(height: 8),
            Text(
              title,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w700,
                color: isOffer ? AppColors.accentDark : AppColors.primaryDark,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
