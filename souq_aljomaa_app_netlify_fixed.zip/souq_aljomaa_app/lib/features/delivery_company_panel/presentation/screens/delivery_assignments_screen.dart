import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../data/models/delivery_panel_models.dart';
import '../../data/repositories/delivery_repository.dart';
import '../providers/delivery_provider.dart';

class DeliveryAssignmentsScreen extends ConsumerStatefulWidget {
  const DeliveryAssignmentsScreen({super.key});

  @override
  ConsumerState<DeliveryAssignmentsScreen> createState() => _DeliveryAssignmentsScreenState();
}

class _DeliveryAssignmentsScreenState extends ConsumerState<DeliveryAssignmentsScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabController = TabController(length: 2, vsync: this);

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('طلبات التوصيل'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [Tab(text: 'طلبات جديدة'), Tab(text: 'قيد التنفيذ')],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: const [_PendingTab(), _ActiveTab()],
      ),
    );
  }
}

class _PendingTab extends ConsumerWidget {
  const _PendingTab();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final pendingAsync = ref.watch(pendingAssignmentsProvider);

    return pendingAsync.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => Center(child: Text('تعذّر التحميل: $e')),
      data: (assignments) => assignments.isEmpty
          ? const Center(child: Text('لا توجد طلبات جديدة بانتظار قبولك'))
          : RefreshIndicator(
              onRefresh: () async => ref.invalidate(pendingAssignmentsProvider),
              child: ListView.separated(
                padding: const EdgeInsets.all(12),
                itemCount: assignments.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (context, i) => _PendingTile(assignment: assignments[i]),
              ),
            ),
    );
  }
}

class _PendingTile extends ConsumerWidget {
  const _PendingTile({required this.assignment});
  final DeliveryAssignmentModel assignment;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('طلب #${assignment.orderId}', style: const TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          Text('${assignment.itemsCount} منتج · ${assignment.grandTotal.toStringAsFixed(0)} د.ع',
              style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
          Text(assignment.addressLabel, style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () async {
                    await deliveryRepository.rejectAssignment(assignment.orderId);
                    ref.invalidate(pendingAssignmentsProvider);
                  },
                  style: OutlinedButton.styleFrom(foregroundColor: AppColors.danger),
                  child: const Text('رفض'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: ElevatedButton(
                  onPressed: () async {
                    await deliveryRepository.acceptAssignment(assignment.orderId);
                    ref.invalidate(pendingAssignmentsProvider);
                    ref.invalidate(activeAssignmentsProvider);
                  },
                  style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary, foregroundColor: Colors.white),
                  child: const Text('قبول'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _ActiveTab extends ConsumerWidget {
  const _ActiveTab();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final activeAsync = ref.watch(activeAssignmentsProvider);

    return activeAsync.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => Center(child: Text('تعذّر التحميل: $e')),
      data: (assignments) => assignments.isEmpty
          ? const Center(child: Text('لا توجد طلبات قيد التنفيذ حاليًا'))
          : RefreshIndicator(
              onRefresh: () async => ref.invalidate(activeAssignmentsProvider),
              child: ListView.separated(
                padding: const EdgeInsets.all(12),
                itemCount: assignments.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (context, i) => _ActiveTile(assignment: assignments[i]),
              ),
            ),
    );
  }
}

class _ActiveTile extends ConsumerWidget {
  const _ActiveTile({required this.assignment});
  final DeliveryAssignmentModel assignment;

  Future<void> _confirmDeliveryDialog(BuildContext context, WidgetRef ref) async {
    final controller = TextEditingController();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('تأكيد الاستلام'),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          maxLength: 6,
          decoration: const InputDecoration(labelText: 'رمز التحقق من الزبون'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('إلغاء')),
          ElevatedButton(onPressed: () => Navigator.of(context).pop(true), child: const Text('تأكيد')),
        ],
      ),
    );
    if (confirmed != true || !context.mounted) return;

    final success = await deliveryRepository.confirmDelivery(orderId: assignment.orderId, otp: controller.text.trim());
    if (!context.mounted) return;
    if (success) {
      ref.invalidate(activeAssignmentsProvider);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم تأكيد التسليم بنجاح')));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('رمز التحقق غير صحيح')));
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isPickedUp = assignment.orderStatus == 'out_for_delivery';

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('طلب #${assignment.orderId}', style: const TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          Text(assignment.addressLabel, style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
          Text(isPickedUp ? 'قيد التوصيل — بانتظار تأكيد الاستلام' : 'مقبول — بانتظار استلام الشحنة من البائع',
              style: const TextStyle(color: AppColors.primary, fontSize: 12)),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: isPickedUp
                ? ElevatedButton.icon(
                    onPressed: () => _confirmDeliveryDialog(context, ref),
                    icon: const Icon(Icons.check_circle_outline),
                    label: const Text('تأكيد التسليم (OTP)'),
                    style: ElevatedButton.styleFrom(backgroundColor: AppColors.success, foregroundColor: Colors.white),
                  )
                : ElevatedButton.icon(
                    onPressed: () async {
                      await deliveryRepository.startDelivery(assignment.orderId);
                      ref.invalidate(activeAssignmentsProvider);
                    },
                    icon: const Icon(Icons.local_shipping_outlined),
                    label: const Text('بدء التوصيل (استلمت الشحنة)'),
                    style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary, foregroundColor: Colors.white),
                  ),
          ),
        ],
      ),
    );
  }
}
