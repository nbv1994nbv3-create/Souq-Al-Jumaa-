import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/services/image_upload_service.dart';
import '../../data/repositories/delivery_repository.dart';
import '../providers/delivery_provider.dart';

class BecomeDeliveryCompanyScreen extends ConsumerStatefulWidget {
  const BecomeDeliveryCompanyScreen({super.key});

  @override
  ConsumerState<BecomeDeliveryCompanyScreen> createState() => _BecomeDeliveryCompanyScreenState();
}

class _BecomeDeliveryCompanyScreenState extends ConsumerState<BecomeDeliveryCompanyScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  bool _isSubmitting = false;
  String? _logoUrl;
  bool _isUploadingLogo = false;

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isSubmitting = true);
    try {
      await deliveryRepository.applyAsDeliveryCompany(companyName: _nameController.text.trim(), logoUrl: _logoUrl);
      ref.invalidate(myDeliveryCompanyProvider);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذّر إرسال الطلب: $e')));
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('سجّل شركة توصيل')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Icon(Icons.local_shipping_outlined, size: 56, color: AppColors.primary),
            const SizedBox(height: 12),
            const Text(
              'سجّل شركتك لتوصيل طلبات سوق الجمعة وتحديد مناطق التغطية وأسعار الشحن',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.textSecondary),
            ),
            const SizedBox(height: 24),
            const SizedBox(height: 24),
            Center(
              child: GestureDetector(
                onTap: _isUploadingLogo
                    ? null
                    : () async {
                        setState(() => _isUploadingLogo = true);
                        try {
                          final url = await imageUploadService.pickAndUpload(folder: 'delivery-logos');
                          if (url != null) setState(() => _logoUrl = url);
                        } finally {
                          if (mounted) setState(() => _isUploadingLogo = false);
                        }
                      },
                child: CircleAvatar(
                  radius: 40,
                  backgroundColor: AppColors.primaryLight,
                  backgroundImage: _logoUrl != null ? CachedNetworkImageProvider(_logoUrl!) : null,
                  child: _isUploadingLogo
                      ? const CircularProgressIndicator(strokeWidth: 2)
                      : (_logoUrl == null ? const Icon(Icons.add_a_photo_outlined, color: AppColors.primary) : null),
                ),
              ),
            ),
            const SizedBox(height: 8),
            const Text('شعار الشركة (اختياري)', textAlign: TextAlign.center, style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
            const SizedBox(height: 12),
            TextFormField(
              controller: _nameController,
              decoration: const InputDecoration(labelText: 'اسم شركة التوصيل', border: OutlineInputBorder()),
              validator: (v) => (v == null || v.trim().isEmpty) ? 'أدخل اسم الشركة' : null,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _isSubmitting ? null : _submit,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              child: _isSubmitting
                  ? const SizedBox(
                      width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Text('إرسال طلب التسجيل'),
            ),
          ],
        ),
      ),
    );
  }
}
