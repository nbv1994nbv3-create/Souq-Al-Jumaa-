import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/theme/app_colors.dart';
import '../providers/delivery_provider.dart';
import 'become_delivery_company_screen.dart';

class DeliveryDashboardScreen extends ConsumerWidget {
  const DeliveryDashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final companyAsync = ref.watch(myDeliveryCompanyProvider);

    return companyAsync.when(
      loading: () => const Scaffold(body: Center(child: CircularProgressIndicator())),
      error: (e, _) => Scaffold(body: Center(child: Text('تعذّر تحميل بيانات الشركة: $e'))),
      data: (company) {
        if (company == null) return const BecomeDeliveryCompanyScreen();

        final approved = company['approved_by_admin'] as bool? ?? false;
        final companyName = company['company_name'] as String? ?? '';

        return Scaffold(
          appBar: AppBar(title: Text(companyName)),
          body: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              if (!approved)
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.warning.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.hourglass_top_outlined, color: AppColors.warning),
                      SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'شركتك بانتظار موافقة الإدارة. عرّف مناطق تغطيتك الآن، وستبدأ تلقي طلبات التوصيل بعد الموافقة.',
                          style: TextStyle(color: AppColors.warning, fontSize: 13),
                        ),
                      ),
                    ],
                  ),
                ),
              const SizedBox(height: 16),
              _Tile(
                icon: Icons.map_outlined,
                title: 'مناطق التغطية',
                subtitle: 'حدّد المحافظات والمناطق وأسعار الشحن',
                onTap: () => context.push('/delivery/coverage-areas'),
              ),
              const SizedBox(height: 12),
              _Tile(
                icon: Icons.local_shipping_outlined,
                title: 'طلبات التوصيل',
                subtitle: 'اقبل الطلبات الجديدة وتابع التوصيل الجاري',
                onTap: () => context.push('/delivery/assignments'),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _Tile extends StatelessWidget {
  const _Tile({required this.icon, required this.title, required this.subtitle, required this.onTap});
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            CircleAvatar(backgroundColor: AppColors.primaryLight, child: Icon(icon, color: AppColors.primary)),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
                  Text(subtitle, style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                ],
              ),
            ),
            const Icon(Icons.arrow_back_ios, size: 14, color: AppColors.textSecondary),
          ],
        ),
      ),
    );
  }
}
