import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../checkout/data/models/address_model.dart';
import '../../data/models/delivery_panel_models.dart';
import '../../data/repositories/delivery_repository.dart';
import '../providers/delivery_provider.dart';

class CoverageAreasScreen extends ConsumerWidget {
  const CoverageAreasScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final areasAsync = ref.watch(coverageAreasProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('مناطق التغطية')),
      body: areasAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('تعذّر تحميل المناطق: $e')),
        data: (areas) => areas.isEmpty
            ? const Center(child: Text('لم تُضف أي منطقة تغطية بعد'))
            : ListView.separated(
                padding: const EdgeInsets.all(12),
                itemCount: areas.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (context, i) => _AreaTile(area: areas[i]),
              ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => showModalBottomSheet(
          context: context,
          isScrollControlled: true,
          builder: (_) => const _AddCoverageAreaSheet(),
        ),
        icon: const Icon(Icons.add_location_alt_outlined),
        label: const Text('منطقة جديدة'),
      ),
    );
  }
}

class _AreaTile extends ConsumerWidget {
  const _AreaTile({required this.area});
  final CoverageAreaModel area;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('${area.governorate} - ${area.region}', style: const TextStyle(fontWeight: FontWeight.w600)),
                Text(
                  '${area.shippingCost.toStringAsFixed(0)} د.ع · ${area.shippingType == 'express' ? 'سريع' : 'عادي'} · خلال ${area.expectedDurationHours} ساعة',
                  style: const TextStyle(color: AppColors.textSecondary, fontSize: 12),
                ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline, color: AppColors.danger),
            onPressed: () async {
              await deliveryRepository.deleteCoverageArea(area.id);
              ref.invalidate(coverageAreasProvider);
            },
          ),
        ],
      ),
    );
  }
}

class _AddCoverageAreaSheet extends ConsumerStatefulWidget {
  const _AddCoverageAreaSheet();

  @override
  ConsumerState<_AddCoverageAreaSheet> createState() => _AddCoverageAreaSheetState();
}

class _AddCoverageAreaSheetState extends ConsumerState<_AddCoverageAreaSheet> {
  final _formKey = GlobalKey<FormState>();
  String? _governorate;
  final _regionController = TextEditingController();
  final _costController = TextEditingController();
  final _durationController = TextEditingController(text: '24');
  String _shippingType = 'normal';
  bool _isSaving = false;

  Future<void> _save() async {
    if (!_formKey.currentState!.validate() || _governorate == null) return;
    setState(() => _isSaving = true);
    try {
      await deliveryRepository.addCoverageArea(
        governorate: _governorate!,
        region: _regionController.text.trim(),
        shippingCost: double.parse(_costController.text.trim()),
        expectedDurationHours: int.parse(_durationController.text.trim()),
        shippingType: _shippingType,
      );
      ref.invalidate(coverageAreasProvider);
      if (mounted) Navigator.of(context).pop();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذّر الحفظ: $e')));
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 16, right: 16, top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 16,
      ),
      child: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('إضافة منطقة تغطية', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              initialValue: _governorate,
              decoration: const InputDecoration(labelText: 'المحافظة', border: OutlineInputBorder()),
              items: iraqGovernorates.map((g) => DropdownMenuItem(value: g, child: Text(g))).toList(),
              onChanged: (v) => setState(() => _governorate = v),
              validator: (v) => v == null ? 'اختر المحافظة' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _regionController,
              decoration: const InputDecoration(labelText: 'المنطقة', border: OutlineInputBorder()),
              validator: (v) => (v == null || v.trim().isEmpty) ? 'مطلوب' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _costController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(labelText: 'تكلفة الشحن (د.ع)', border: OutlineInputBorder()),
              validator: (v) => (v == null || double.tryParse(v.trim()) == null) ? 'رقم غير صحيح' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _durationController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'مدة التوصيل المتوقعة (ساعة)', border: OutlineInputBorder()),
              validator: (v) => (v == null || int.tryParse(v.trim()) == null) ? 'رقم غير صحيح' : null,
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              initialValue: _shippingType,
              decoration: const InputDecoration(labelText: 'نوع الشحن', border: OutlineInputBorder()),
              items: const [
                DropdownMenuItem(value: 'normal', child: Text('عادي')),
                DropdownMenuItem(value: 'express', child: Text('سريع')),
              ],
              onChanged: (v) => setState(() => _shippingType = v!),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _isSaving ? null : _save,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              child: _isSaving
                  ? const SizedBox(
                      width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Text('حفظ'),
            ),
          ],
        ),
      ),
    );
  }
}
