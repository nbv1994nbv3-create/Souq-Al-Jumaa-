import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/models/delivery_panel_models.dart';
import '../../data/repositories/delivery_repository.dart';

final myDeliveryCompanyProvider = FutureProvider<Map<String, dynamic>?>((ref) {
  return deliveryRepository.fetchMyCompany();
});

final coverageAreasProvider = FutureProvider<List<CoverageAreaModel>>((ref) {
  return deliveryRepository.fetchCoverageAreas();
});

/// طلبات جديدة بانتظار قبول/رفض الشركة.
final pendingAssignmentsProvider = FutureProvider<List<DeliveryAssignmentModel>>((ref) {
  return deliveryRepository.fetchAssignments(status: 'pending');
});

/// طلبات مقبولة قيد التنفيذ (قبل أو أثناء التوصيل).
final activeAssignmentsProvider = FutureProvider<List<DeliveryAssignmentModel>>((ref) async {
  final accepted = await deliveryRepository.fetchAssignments(status: 'accepted');
  final pickedUp = await deliveryRepository.fetchAssignments(status: 'picked_up');
  return [...accepted, ...pickedUp];
});
