/// منطقة تغطية تابعة لشركة التوصيل — يطابق delivery_coverage_areas
class CoverageAreaModel {
  final int id;
  final String governorate;
  final String region;
  final double shippingCost;
  final int expectedDurationHours;
  final String shippingType;
  final bool isActive;

  const CoverageAreaModel({
    required this.id,
    required this.governorate,
    required this.region,
    required this.shippingCost,
    required this.expectedDurationHours,
    required this.shippingType,
    this.isActive = true,
  });

  factory CoverageAreaModel.fromJson(Map<String, dynamic> json) {
    return CoverageAreaModel(
      id: json['id'] as int,
      governorate: json['governorate'] as String,
      region: json['region'] as String,
      shippingCost: (json['shipping_cost'] as num).toDouble(),
      expectedDurationHours: json['expected_duration_hours'] as int,
      shippingType: json['shipping_type'] as String,
      isActive: json['is_active'] as bool? ?? true,
    );
  }
}

/// طلب مُسند لشركة التوصيل — يطابق delivery_assignments مضمّنًا بيانات الطلب
class DeliveryAssignmentModel {
  final int orderId;
  final String assignmentStatus; // pending | accepted | rejected | picked_up | delivered
  final String orderStatus;
  final double grandTotal;
  final String addressLabel;
  final int itemsCount;
  final String? deliveryOtpCode;

  const DeliveryAssignmentModel({
    required this.orderId,
    required this.assignmentStatus,
    required this.orderStatus,
    required this.grandTotal,
    required this.addressLabel,
    required this.itemsCount,
    this.deliveryOtpCode,
  });

  factory DeliveryAssignmentModel.fromJson(Map<String, dynamic> json) {
    final order = json['order'] as Map<String, dynamic>;
    final address = order['address'] as Map<String, dynamic>?;
    final items = order['order_items'] as List<dynamic>? ?? [];

    return DeliveryAssignmentModel(
      orderId: order['id'] as int,
      assignmentStatus: json['status'] as String,
      orderStatus: order['status'] as String,
      grandTotal: (order['grand_total'] as num).toDouble(),
      addressLabel: address == null ? '' : '${address['governorate']} - ${address['region']}',
      itemsCount: items.length,
      deliveryOtpCode: order['delivery_otp_code'] as String?,
    );
  }
}
