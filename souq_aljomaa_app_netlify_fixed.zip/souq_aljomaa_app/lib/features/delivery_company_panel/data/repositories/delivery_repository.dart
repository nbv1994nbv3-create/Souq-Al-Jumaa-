import '../../../../core/network/supabase_config.dart';
import '../models/delivery_panel_models.dart';

const _assignmentSelect = '''
  status,
  order:orders(
    id, status, grand_total, delivery_otp_code,
    address:addresses(governorate, region),
    order_items(id)
  )
''';

class DeliveryRepository {
  String get _companyId => supabase.auth.currentUser!.id;

  Future<void> applyAsDeliveryCompany({required String companyName, String? logoUrl}) async {
    await supabase.rpc('apply_as_delivery_company', params: {'p_company_name': companyName});
    if (logoUrl != null) {
      await supabase.from('delivery_companies').update({'logo_url': logoUrl}).eq('id', _companyId);
    }
  }

  Future<Map<String, dynamic>?> fetchMyCompany() async {
    return await supabase.from('delivery_companies').select().eq('id', _companyId).maybeSingle();
  }

  Future<List<CoverageAreaModel>> fetchCoverageAreas() async {
    final rows = await supabase
        .from('delivery_coverage_areas')
        .select()
        .eq('delivery_company_id', _companyId)
        .order('governorate');
    return rows.map((e) => CoverageAreaModel.fromJson(e)).toList();
  }

  Future<void> addCoverageArea({
    required String governorate,
    required String region,
    required double shippingCost,
    required int expectedDurationHours,
    required String shippingType,
  }) async {
    await supabase.from('delivery_coverage_areas').insert({
      'delivery_company_id': _companyId,
      'governorate': governorate,
      'region': region,
      'shipping_cost': shippingCost,
      'expected_duration_hours': expectedDurationHours,
      'shipping_type': shippingType,
    });
  }

  Future<void> deleteCoverageArea(int id) async {
    await supabase.from('delivery_coverage_areas').delete().eq('id', id);
  }

  /// طلبات مُسندة لهذه الشركة بحالة معيّنة (أو الكل إذا null).
  Future<List<DeliveryAssignmentModel>> fetchAssignments({String? status}) async {
    var query = supabase.from('delivery_assignments').select(_assignmentSelect).eq('delivery_company_id', _companyId);
    if (status != null) query = query.eq('status', status);
    final rows = await query.order('assigned_at', ascending: false);
    return rows.map((e) => DeliveryAssignmentModel.fromJson(e)).toList();
  }

  Future<void> acceptAssignment(int orderId) async {
    await supabase.rpc('accept_delivery_assignment', params: {'p_order_id': orderId});
  }

  Future<void> rejectAssignment(int orderId) async {
    await supabase.rpc('reject_delivery_assignment', params: {'p_order_id': orderId});
  }

  /// يبدأ التوصيل الفعلي (استلام من البائع) ويولّد رمز OTP، ويعيده لعرضه
  /// للمندوب مؤقتًا (المندوب لا يحتاجه، الزبون هو من يقرأه من تطبيقه،
  /// لكن نعيده هنا احتياطًا لأغراض الدعم الفني).
  Future<String> startDelivery(int orderId) async {
    final otp = await supabase.rpc('mark_order_out_for_delivery', params: {'p_order_id': orderId});
    return otp as String;
  }

  /// يؤكد التسليم بمطابقة رمز OTP الذي أعطاه الزبون للمندوب.
  Future<bool> confirmDelivery({required int orderId, required String otp}) async {
    final result = await supabase.rpc('confirm_order_delivery', params: {
      'p_order_id': orderId,
      'p_otp_code': otp,
    });
    return result as bool;
  }
}

final deliveryRepository = DeliveryRepository();
