import '../../../../core/network/supabase_config.dart';
import '../../../products/data/models/product_model.dart';
import '../../../products/data/repositories/products_repository.dart';

class FavoritesRepository {
  String get _customerId => supabase.auth.currentUser!.id;

  /// يجلب كل المنتجات المفضّلة للمستخدم الحالي.
  Future<List<ProductModel>> fetchFavorites() async {
    final rows = await supabase
        .from('favorites')
        .select('product:products($productSelectFragment)')
        .eq('customer_id', _customerId)
        .order('added_at', ascending: false);
    return rows.map((e) => ProductModel.fromJson(e['product'] as Map<String, dynamic>)).toList();
  }

  /// يجلب معرّفات المنتجات المفضّلة فقط (لعرض حالة القلب في القوائم بسرعة).
  Future<Set<int>> fetchFavoriteIds() async {
    final rows =
        await supabase.from('favorites').select('product_id').eq('customer_id', _customerId);
    return rows.map((e) => e['product_id'] as int).toSet();
  }

  Future<void> addFavorite(int productId) async {
    await supabase.from('favorites').insert({
      'customer_id': _customerId,
      'product_id': productId,
    });
  }

  Future<void> removeFavorite(int productId) async {
    await supabase
        .from('favorites')
        .delete()
        .eq('customer_id', _customerId)
        .eq('product_id', productId);
  }
}

final favoritesRepository = FavoritesRepository();
