import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../products/data/models/product_model.dart';
import '../../data/repositories/favorites_repository.dart';

class FavoritesState {
  const FavoritesState({
    this.favoriteIds = const {},
    this.products = const [],
    this.isLoading = false,
  });

  final Set<int> favoriteIds;
  final List<ProductModel> products;
  final bool isLoading;

  bool isFavorite(int productId) => favoriteIds.contains(productId);

  FavoritesState copyWith({Set<int>? favoriteIds, List<ProductModel>? products, bool? isLoading}) {
    return FavoritesState(
      favoriteIds: favoriteIds ?? this.favoriteIds,
      products: products ?? this.products,
      isLoading: isLoading ?? this.isLoading,
    );
  }
}

class FavoritesController extends StateNotifier<FavoritesState> {
  FavoritesController() : super(const FavoritesState()) {
    loadFavorites();
  }

  Future<void> loadFavorites() async {
    state = state.copyWith(isLoading: true);
    final products = await favoritesRepository.fetchFavorites();
    state = state.copyWith(
      products: products,
      favoriteIds: products.map((p) => p.id).toSet(),
      isLoading: false,
    );
  }

  /// يبدّل حالة المفضلة فورًا بالواجهة (تفاؤلي)، ثم يزامن مع الخادم.
  Future<void> toggle(int productId) async {
    final isCurrentlyFavorite = state.favoriteIds.contains(productId);
    final newIds = {...state.favoriteIds};
    isCurrentlyFavorite ? newIds.remove(productId) : newIds.add(productId);
    state = state.copyWith(favoriteIds: newIds);

    try {
      if (isCurrentlyFavorite) {
        await favoritesRepository.removeFavorite(productId);
      } else {
        await favoritesRepository.addFavorite(productId);
      }
      // إعادة تحميل القائمة الكاملة فقط إذا كانت الشاشة تعرضها بالفعل
      if (state.products.isNotEmpty || !isCurrentlyFavorite) {
        await loadFavorites();
      }
    } catch (_) {
      // تراجع عن التبديل التفاؤلي عند فشل الطلب
      state = state.copyWith(favoriteIds: state.favoriteIds);
      await loadFavorites();
    }
  }
}

final favoritesProvider = StateNotifierProvider<FavoritesController, FavoritesState>((ref) {
  return FavoritesController();
});
