import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../products/presentation/widgets/product_card.dart';
import '../providers/favorites_provider.dart';

class FavoritesScreen extends ConsumerWidget {
  const FavoritesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final favorites = ref.watch(favoritesProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('المفضلة')),
      body: favorites.isLoading && favorites.products.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : favorites.products.isEmpty
              ? const Center(child: Text('لا توجد منتجات في المفضلة بعد'))
              : RefreshIndicator(
                  onRefresh: () => ref.read(favoritesProvider.notifier).loadFavorites(),
                  child: GridView.builder(
                    padding: const EdgeInsets.all(12),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      mainAxisSpacing: 12,
                      crossAxisSpacing: 12,
                      childAspectRatio: 0.68,
                    ),
                    itemCount: favorites.products.length,
                    itemBuilder: (context, i) {
                      final product = favorites.products[i];
                      return ProductCard(
                        product: product,
                        onTap: () => context.push('/product/${product.id}'),
                      );
                    },
                  ),
                ),
    );
  }
}
