import '../../../../core/network/supabase_config.dart';
import '../../../products/data/models/product_model.dart';
import '../../../products/data/repositories/products_repository.dart';
import '../models/seller_models.dart';

class SellerRepository {
  String get _sellerId => supabase.auth.currentUser!.id;

  /// يقدّم طلبًا ليصبح المستخدم الحالي بائعًا (يُنشئ متجره تلقائيًا).
  Future<void> applyAsSeller({required String storeName, String? description, String? logoUrl}) async {
    await supabase.rpc('apply_as_seller', params: {
      'p_store_name': storeName,
      'p_store_description': description,
    });
    if (logoUrl != null) {
      await supabase.from('sellers').update({'store_logo_url': logoUrl}).eq('id', _sellerId);
    }
  }

  /// يجلب صف متجر المستخدم الحالي، أو null إذا لم يقدّم طلب بعد.
  Future<Map<String, dynamic>?> fetchMyStore() async {
    return await supabase.from('sellers').select().eq('id', _sellerId).maybeSingle();
  }

  Future<List<ProductModel>> fetchMyProducts() async {
    final rows = await supabase
        .from('products')
        .select(productSelectFragment)
        .eq('seller_id', _sellerId)
        .order('created_at', ascending: false);
    return rows.map((e) => ProductModel.fromJson(e)).toList();
  }

  /// ينشئ منتجًا جديدًا (حالته الافتراضية pending_review بانتظار مراجعة
  /// الإدارة)، مع صورة واحدة اختيارية وحقول القسم المتخصصة إن وُجدت.
  Future<int> createProduct({
    required int categoryId,
    required String title,
    String? description,
    required double price,
    double? discountPrice,
    required int quantity,
    bool isOffer = false,
    List<String> imageUrls = const [],
    Map<String, dynamic>? realEstateDetails,
    Map<String, dynamic>? phoneDetails,
    Map<String, dynamic>? generatorDetails,
  }) async {
    final productRow = await supabase
        .from('products')
        .insert({
          'seller_id': _sellerId,
          'category_id': categoryId,
          'title': title,
          'description': description,
          'price': price,
          'discount_price': discountPrice,
          'quantity': quantity,
          'is_offer': isOffer,
        })
        .select('id')
        .single();
    final productId = productRow['id'] as int;

    if (imageUrls.isNotEmpty) {
      await supabase.from('product_images').insert([
        for (var i = 0; i < imageUrls.length; i++)
          {'product_id': productId, 'image_url': imageUrls[i], 'sort_order': i},
      ]);
    }

    if (realEstateDetails != null) {
      await supabase.from('real_estate_details').insert({'product_id': productId, ...realEstateDetails});
    } else if (phoneDetails != null) {
      await supabase.from('phone_details').insert({'product_id': productId, ...phoneDetails});
    } else if (generatorDetails != null) {
      await supabase.from('generator_details').insert({'product_id': productId, ...generatorDetails});
    }

    return productId;
  }

  /// يبدّل حالة نشاط المنتج بين "نشط" و"مؤرشف" (لا حذف نهائي حفاظًا على
  /// سجل الطلبات السابقة المرتبطة به).
  Future<void> setProductStatus(int productId, String status) async {
    await supabase.from('products').update({'status': status}).eq('id', productId);
  }

  Future<void> updateStock({required int productId, required int quantity}) async {
    await supabase.from('products').update({'quantity': quantity}).eq('id', productId);
  }

  /// طلبات تحتوي على منتجات هذا البائع.
  Future<List<SellerOrderItemModel>> fetchSellerOrderItems() async {
    final rows = await supabase
        .from('order_items')
        .select('quantity, subtotal, order:orders(id, status, created_at), product:products(title)')
        .eq('seller_id', _sellerId)
        .order('id', ascending: false);
    return rows.map((e) => SellerOrderItemModel.fromJson(e)).toList();
  }

  Future<SalesSummaryModel> fetchSalesSummary() async {
    final rows = await supabase.rpc('seller_sales_summary');
    if (rows is List && rows.isNotEmpty) {
      return SalesSummaryModel.fromJson(rows.first as Map<String, dynamic>);
    }
    return SalesSummaryModel.empty();
  }
}

final sellerRepository = SellerRepository();
