class SalesSummaryModel {
  final int totalOrders;
  final double totalRevenue;
  final double totalCommission;
  final double netRevenue;

  const SalesSummaryModel({
    required this.totalOrders,
    required this.totalRevenue,
    required this.totalCommission,
    required this.netRevenue,
  });

  factory SalesSummaryModel.fromJson(Map<String, dynamic> json) {
    return SalesSummaryModel(
      totalOrders: json['total_orders'] as int,
      totalRevenue: (json['total_revenue'] as num).toDouble(),
      totalCommission: (json['total_commission'] as num).toDouble(),
      netRevenue: (json['net_revenue'] as num).toDouble(),
    );
  }

  factory SalesSummaryModel.empty() => const SalesSummaryModel(
        totalOrders: 0,
        totalRevenue: 0,
        totalCommission: 0,
        netRevenue: 0,
      );
}

/// صف طلب يحتوي على منتجات هذا البائع (لعرضه في "طلبات متجري")
class SellerOrderItemModel {
  final int orderId;
  final String orderStatus;
  final DateTime orderCreatedAt;
  final String productTitle;
  final int quantity;
  final double subtotal;

  const SellerOrderItemModel({
    required this.orderId,
    required this.orderStatus,
    required this.orderCreatedAt,
    required this.productTitle,
    required this.quantity,
    required this.subtotal,
  });

  factory SellerOrderItemModel.fromJson(Map<String, dynamic> json) {
    final order = json['order'] as Map<String, dynamic>;
    final product = json['product'] as Map<String, dynamic>;
    return SellerOrderItemModel(
      orderId: order['id'] as int,
      orderStatus: order['status'] as String,
      orderCreatedAt: DateTime.parse(order['created_at'] as String),
      productTitle: product['title'] as String,
      quantity: json['quantity'] as int,
      subtotal: (json['subtotal'] as num).toDouble(),
    );
  }
}
