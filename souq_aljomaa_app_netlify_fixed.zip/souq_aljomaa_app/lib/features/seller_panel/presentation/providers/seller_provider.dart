import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../products/data/models/product_model.dart';
import '../../data/models/seller_models.dart';
import '../../data/repositories/seller_repository.dart';

/// صف متجر البائع الحالي، أو null إذا لم يقدّم طلبًا بعد ليصبح بائعًا.
final myStoreProvider = FutureProvider<Map<String, dynamic>?>((ref) {
  return sellerRepository.fetchMyStore();
});

final myProductsProvider = FutureProvider<List<ProductModel>>((ref) {
  return sellerRepository.fetchMyProducts();
});

final sellerOrderItemsProvider = FutureProvider<List<SellerOrderItemModel>>((ref) {
  return sellerRepository.fetchSellerOrderItems();
});

final salesSummaryProvider = FutureProvider<SalesSummaryModel>((ref) {
  return sellerRepository.fetchSalesSummary();
});
