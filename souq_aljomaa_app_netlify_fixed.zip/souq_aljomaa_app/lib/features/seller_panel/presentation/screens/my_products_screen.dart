import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../products/data/models/product_model.dart';
import '../../data/repositories/seller_repository.dart';
import '../providers/seller_provider.dart';

const _statusLabels = {
  'pending_review': 'بانتظار المراجعة',
  'active': 'نشط',
  'sold_out': 'نفدت الكمية',
  'rejected': 'مرفوض',
  'archived': 'مؤرشف',
};

class MyProductsScreen extends ConsumerWidget {
  const MyProductsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final productsAsync = ref.watch(myProductsProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('منتجاتي')),
      body: productsAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('تعذّر تحميل المنتجات: $e')),
        data: (products) => products.isEmpty
            ? const Center(child: Text('لم تُضف أي منتجات بعد'))
            : RefreshIndicator(
                onRefresh: () async => ref.invalidate(myProductsProvider),
                child: ListView.separated(
                  padding: const EdgeInsets.all(12),
                  itemCount: products.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (context, i) => _MyProductTile(product: products[i]),
                ),
              ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => context.push('/seller/products/new'),
        icon: const Icon(Icons.add),
        label: const Text('منتج جديد'),
      ),
    );
  }
}

class _MyProductTile extends ConsumerWidget {
  const _MyProductTile({required this.product});
  final ProductModel product;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: SizedBox(
              width: 60,
              height: 60,
              child: product.imageUrls.isNotEmpty
                  ? CachedNetworkImage(imageUrl: product.imageUrls.first, fit: BoxFit.cover)
                  : Container(color: AppColors.primaryLight, child: const Icon(Icons.image_outlined)),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(product.title, maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 2),
                Text('${product.displayPrice.toStringAsFixed(0)} د.ع · الكمية: ${product.quantity}',
                    style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                const SizedBox(height: 2),
                Text(_statusLabels[product.status] ?? product.status,
                    style: const TextStyle(color: AppColors.primary, fontSize: 11, fontWeight: FontWeight.w600)),
              ],
            ),
          ),
          PopupMenuButton<String>(
            onSelected: (status) async {
              await sellerRepository.setProductStatus(product.id, status);
              ref.invalidate(myProductsProvider);
            },
            itemBuilder: (context) => const [
              PopupMenuItem(value: 'active', child: Text('تفعيل')),
              PopupMenuItem(value: 'archived', child: Text('أرشفة')),
            ],
            child: const Padding(
              padding: EdgeInsets.all(4),
              child: Icon(Icons.more_vert, color: AppColors.textSecondary),
            ),
          ),
        ],
      ),
    );
  }
}
