import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../orders/data/models/order_model.dart';
import '../../data/models/seller_models.dart';
import '../providers/seller_provider.dart';

class SellerOrdersScreen extends ConsumerWidget {
  const SellerOrdersScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final itemsAsync = ref.watch(sellerOrderItemsProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('طلبات متجري')),
      body: itemsAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('تعذّر تحميل الطلبات: $e')),
        data: (items) => items.isEmpty
            ? const Center(child: Text('لا توجد طلبات على منتجاتك بعد'))
            : RefreshIndicator(
                onRefresh: () async => ref.invalidate(sellerOrderItemsProvider),
                child: ListView.separated(
                  padding: const EdgeInsets.all(12),
                  itemCount: items.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (context, i) => _SellerOrderItemTile(item: items[i]),
                ),
              ),
      ),
    );
  }
}

class _SellerOrderItemTile extends StatelessWidget {
  const _SellerOrderItemTile({required this.item});
  final SellerOrderItemModel item;

  @override
  Widget build(BuildContext context) {
    final status = OrderStatus.fromDb(item.orderStatus);
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item.productTitle, style: const TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 2),
                Text('طلب #${item.orderId} · الكمية: ${item.quantity}',
                    style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                Text(status.label, style: const TextStyle(color: AppColors.primary, fontSize: 12)),
              ],
            ),
          ),
          Text('${item.subtotal.toStringAsFixed(0)} د.ع', style: const TextStyle(fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}
