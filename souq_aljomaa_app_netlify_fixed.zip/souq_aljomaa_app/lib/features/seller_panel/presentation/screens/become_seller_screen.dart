import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/services/image_upload_service.dart';
import '../../data/repositories/seller_repository.dart';
import '../providers/seller_provider.dart';

class BecomeSellerScreen extends ConsumerStatefulWidget {
  const BecomeSellerScreen({super.key});

  @override
  ConsumerState<BecomeSellerScreen> createState() => _BecomeSellerScreenState();
}

class _BecomeSellerScreenState extends ConsumerState<BecomeSellerScreen> {
  final _formKey = GlobalKey<FormState>();
  final _storeNameController = TextEditingController();
  final _descriptionController = TextEditingController();
  bool _isSubmitting = false;
  String? _logoUrl;
  bool _isUploadingLogo = false;

  @override
  void dispose() {
    _storeNameController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isSubmitting = true);
    try {
      await sellerRepository.applyAsSeller(
        storeName: _storeNameController.text.trim(),
        description: _descriptionController.text.trim().isEmpty ? null : _descriptionController.text.trim(),
        logoUrl: _logoUrl,
      );
      ref.invalidate(myStoreProvider);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذّر إرسال الطلب: $e')));
      }
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('كن بائعًا')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Icon(Icons.storefront_outlined, size: 56, color: AppColors.primary),
            const SizedBox(height: 12),
            const Text(
              'افتح متجرك الخاص في سوق الجمعة وابدأ بعرض منتجاتك',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.textSecondary),
            ),
            const SizedBox(height: 24),
            const SizedBox(height: 24),
            Center(
              child: GestureDetector(
                onTap: _isUploadingLogo
                    ? null
                    : () async {
                        setState(() => _isUploadingLogo = true);
                        try {
                          final url = await imageUploadService.pickAndUpload(folder: 'store-logos');
                          if (url != null) setState(() => _logoUrl = url);
                        } finally {
                          if (mounted) setState(() => _isUploadingLogo = false);
                        }
                      },
                child: CircleAvatar(
                  radius: 40,
                  backgroundColor: AppColors.primaryLight,
                  backgroundImage: _logoUrl != null ? CachedNetworkImageProvider(_logoUrl!) : null,
                  child: _isUploadingLogo
                      ? const CircularProgressIndicator(strokeWidth: 2)
                      : (_logoUrl == null ? const Icon(Icons.add_a_photo_outlined, color: AppColors.primary) : null),
                ),
              ),
            ),
            const SizedBox(height: 8),
            const Text('شعار المتجر (اختياري)', textAlign: TextAlign.center, style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
            const SizedBox(height: 12),
            TextFormField(
              controller: _storeNameController,
              decoration: const InputDecoration(labelText: 'اسم المتجر', border: OutlineInputBorder()),
              validator: (v) => (v == null || v.trim().isEmpty) ? 'أدخل اسم المتجر' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _descriptionController,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: 'نبذة عن المتجر (اختياري)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _isSubmitting ? null : _submit,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              child: _isSubmitting
                  ? const SizedBox(
                      width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Text('إرسال طلب فتح متجر'),
            ),
          ],
        ),
      ),
    );
  }
}
