import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/theme/app_colors.dart';
import '../providers/seller_provider.dart';
import 'become_seller_screen.dart';

class SellerDashboardScreen extends ConsumerWidget {
  const SellerDashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final storeAsync = ref.watch(myStoreProvider);

    return storeAsync.when(
      loading: () => const Scaffold(body: Center(child: CircularProgressIndicator())),
      error: (e, _) => Scaffold(body: Center(child: Text('تعذّر تحميل بيانات المتجر: $e'))),
      data: (store) {
        if (store == null) return const BecomeSellerScreen();

        final approved = store['approved_by_admin'] as bool? ?? false;
        final storeName = store['store_name'] as String? ?? '';

        return Scaffold(
          appBar: AppBar(title: Text(storeName)),
          body: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              if (!approved) const _PendingApprovalBanner(),
              const SizedBox(height: 16),
              _DashboardTile(
                icon: Icons.inventory_2_outlined,
                title: 'منتجاتي',
                subtitle: 'أضف وأدر منتجات متجرك',
                onTap: () => context.push('/seller/products'),
              ),
              const SizedBox(height: 12),
              _DashboardTile(
                icon: Icons.receipt_long_outlined,
                title: 'طلبات متجري',
                subtitle: 'تابع الطلبات على منتجاتك',
                onTap: () => context.push('/seller/orders'),
              ),
              const SizedBox(height: 12),
              _DashboardTile(
                icon: Icons.bar_chart_outlined,
                title: 'تقرير المبيعات',
                subtitle: 'إجمالي المبيعات والعمولة وصافي الأرباح',
                onTap: () => context.push('/seller/sales-report'),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _PendingApprovalBanner extends StatelessWidget {
  const _PendingApprovalBanner();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.warning.withOpacity(0.1),
        borderRadius: BorderRadius.circular(10),
      ),
      child: const Row(
        children: [
          Icon(Icons.hourglass_top_outlined, color: AppColors.warning),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              'متجرك بانتظار موافقة الإدارة. يمكنك إضافة منتجاتك الآن وستظهر للزبائن بعد الموافقة.',
              style: TextStyle(color: AppColors.warning, fontSize: 13),
            ),
          ),
        ],
      ),
    );
  }
}

class _DashboardTile extends StatelessWidget {
  const _DashboardTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            CircleAvatar(backgroundColor: AppColors.primaryLight, child: Icon(icon, color: AppColors.primary)),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
                  Text(subtitle, style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                ],
              ),
            ),
            const Icon(Icons.arrow_back_ios, size: 14, color: AppColors.textSecondary),
          ],
        ),
      ),
    );
  }
}
