import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../providers/seller_provider.dart';

class SalesReportScreen extends ConsumerWidget {
  const SalesReportScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final summaryAsync = ref.watch(salesSummaryProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('تقرير المبيعات')),
      body: summaryAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('تعذّر تحميل التقرير: $e')),
        data: (summary) => RefreshIndicator(
          onRefresh: () async => ref.invalidate(salesSummaryProvider),
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _SummaryCard(
                icon: Icons.receipt_long_outlined,
                label: 'عدد الطلبات',
                value: '${summary.totalOrders}',
              ),
              const SizedBox(height: 12),
              _SummaryCard(
                icon: Icons.payments_outlined,
                label: 'إجمالي المبيعات',
                value: '${summary.totalRevenue.toStringAsFixed(0)} د.ع',
              ),
              const SizedBox(height: 12),
              _SummaryCard(
                icon: Icons.percent_outlined,
                label: 'عمولة المنصة',
                value: '${summary.totalCommission.toStringAsFixed(0)} د.ع',
                color: AppColors.warning,
              ),
              const SizedBox(height: 12),
              _SummaryCard(
                icon: Icons.account_balance_wallet_outlined,
                label: 'صافي أرباحك',
                value: '${summary.netRevenue.toStringAsFixed(0)} د.ع',
                color: AppColors.success,
                emphasize: true,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({
    required this.icon,
    required this.label,
    required this.value,
    this.color = AppColors.primary,
    this.emphasize = false,
  });

  final IconData icon;
  final String label;
  final String value;
  final Color color;
  final bool emphasize;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: emphasize ? color.withOpacity(0.1) : AppColors.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: emphasize ? color.withOpacity(0.3) : AppColors.border),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 28),
          const SizedBox(width: 14),
          Expanded(child: Text(label, style: const TextStyle(color: AppColors.textSecondary))),
          Text(
            value,
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: emphasize ? color : AppColors.textPrimary),
          ),
        ],
      ),
    );
  }
}
