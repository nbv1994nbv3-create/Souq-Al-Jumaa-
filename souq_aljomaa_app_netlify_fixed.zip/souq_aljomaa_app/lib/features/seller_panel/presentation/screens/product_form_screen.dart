import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/services/image_upload_service.dart';
import '../../../products/data/models/category_model.dart';
import '../../../products/presentation/providers/products_provider.dart';
import '../../data/repositories/seller_repository.dart';
import '../providers/seller_provider.dart';

class ProductFormScreen extends ConsumerStatefulWidget {
  const ProductFormScreen({super.key});

  @override
  ConsumerState<ProductFormScreen> createState() => _ProductFormScreenState();
}

class _ProductFormScreenState extends ConsumerState<ProductFormScreen> {
  final _formKey = GlobalKey<FormState>();

  CategoryModel? _category;
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _priceController = TextEditingController();
  final _discountController = TextEditingController();
  final _quantityController = TextEditingController(text: '1');
  final List<String> _imageUrls = [];
  bool _isUploadingImage = false;
  bool _isOffer = false;
  bool _isSaving = false;

  // -------- حقول العقارات --------
  String _listingType = 'sale';
  final _propertyTypeController = TextEditingController();
  final _governorateController = TextEditingController();
  final _regionController = TextEditingController();
  final _areaController = TextEditingController();
  final _roomsController = TextEditingController();
  final _contactPhoneController = TextEditingController();

  // -------- حقول الهواتف --------
  final _brandController = TextEditingController();
  final _modelController = TextEditingController();
  final _storageController = TextEditingController();
  String _condition = 'new';
  final _ramController = TextEditingController();
  final _colorController = TextEditingController();
  final _warrantyController = TextEditingController(text: '0');

  // -------- حقول الماطورات --------
  final _powerController = TextEditingController();
  final _fuelController = TextEditingController();
  final _generatorBrandController = TextEditingController();
  final _operatingHoursController = TextEditingController();
  final _manufactureYearController = TextEditingController();
  final _locationController = TextEditingController();

  @override
  void dispose() {
    for (final c in [
      _titleController, _descriptionController, _priceController, _discountController,
      _quantityController, _propertyTypeController, _governorateController,
      _regionController, _areaController, _roomsController, _contactPhoneController,
      _brandController, _modelController, _storageController, _ramController, _colorController,
      _warrantyController, _powerController, _fuelController, _generatorBrandController,
      _operatingHoursController, _manufactureYearController, _locationController,
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _pickImages() async {
    setState(() => _isUploadingImage = true);
    try {
      final urls = await imageUploadService.pickAndUploadMultiple(folder: 'products');
      setState(() => _imageUrls.addAll(urls));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذّر رفع الصورة: $e')));
    } finally {
      if (mounted) setState(() => _isUploadingImage = false);
    }
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate() || _category == null) {
      if (_category == null) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('اختر القسم أولاً')));
      }
      return;
    }

    setState(() => _isSaving = true);
    try {
      await sellerRepository.createProduct(
        categoryId: _category!.id,
        title: _titleController.text.trim(),
        description: _descriptionController.text.trim().isEmpty ? null : _descriptionController.text.trim(),
        price: double.parse(_priceController.text.trim()),
        discountPrice: _discountController.text.trim().isEmpty ? null : double.parse(_discountController.text.trim()),
        quantity: int.parse(_quantityController.text.trim()),
        isOffer: _isOffer,
        imageUrls: _imageUrls,
        realEstateDetails: _category!.slug == 'real_estate' ? _buildRealEstateDetails() : null,
        phoneDetails: _category!.slug == 'phones' ? _buildPhoneDetails() : null,
        generatorDetails: _category!.slug == 'generators' ? _buildGeneratorDetails() : null,
      );
      ref.invalidate(myProductsProvider);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('أُضيف المنتج بنجاح، بانتظار مراجعة الإدارة')),
        );
        context.pop();
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذّر حفظ المنتج: $e')));
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  Map<String, dynamic> _buildRealEstateDetails() => {
        'listing_type': _listingType,
        'property_type': _propertyTypeController.text.trim(),
        'governorate': _governorateController.text.trim(),
        'region': _regionController.text.trim(),
        'area_sqm': double.parse(_areaController.text.trim()),
        'rooms_count': _roomsController.text.trim().isEmpty ? null : int.parse(_roomsController.text.trim()),
        'contact_phone': _contactPhoneController.text.trim(),
      };

  Map<String, dynamic> _buildPhoneDetails() => {
        'brand': _brandController.text.trim(),
        'model': _modelController.text.trim(),
        'storage_capacity': _storageController.text.trim(),
        'condition': _condition,
        'ram': _ramController.text.trim().isEmpty ? null : _ramController.text.trim(),
        'color': _colorController.text.trim().isEmpty ? null : _colorController.text.trim(),
        'warranty_months': int.tryParse(_warrantyController.text.trim()) ?? 0,
      };

  Map<String, dynamic> _buildGeneratorDetails() => {
        'power_rating': _powerController.text.trim(),
        'fuel_type': _fuelController.text.trim(),
        'brand': _generatorBrandController.text.trim(),
        'condition': _condition,
        'operating_hours':
            _operatingHoursController.text.trim().isEmpty ? null : int.parse(_operatingHoursController.text.trim()),
        'manufacture_year': _manufactureYearController.text.trim().isEmpty
            ? null
            : int.parse(_manufactureYearController.text.trim()),
        'location': _locationController.text.trim().isEmpty ? null : _locationController.text.trim(),
      };

  @override
  Widget build(BuildContext context) {
    final categoriesAsync = ref.watch(categoriesProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('إضافة منتج')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            categoriesAsync.when(
              loading: () => const LinearProgressIndicator(),
              error: (e, _) => Text('تعذّر تحميل الأقسام: $e'),
              data: (categories) => DropdownButtonFormField<CategoryModel>(
                initialValue: _category,
                decoration: const InputDecoration(labelText: 'القسم', border: OutlineInputBorder()),
                items: categories.map((c) => DropdownMenuItem(value: c, child: Text(c.name))).toList(),
                onChanged: (value) => setState(() => _category = value),
              ),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _titleController,
              decoration: const InputDecoration(labelText: 'عنوان المنتج', border: OutlineInputBorder()),
              validator: (v) => (v == null || v.trim().isEmpty) ? 'مطلوب' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _descriptionController,
              maxLines: 3,
              decoration: const InputDecoration(labelText: 'الوصف (اختياري)', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: _priceController,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(labelText: 'السعر (د.ع)', border: OutlineInputBorder()),
                    validator: (v) => (v == null || double.tryParse(v.trim()) == null) ? 'رقم غير صحيح' : null,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: TextFormField(
                    controller: _discountController,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(labelText: 'سعر بعد الخصم (اختياري)', border: OutlineInputBorder()),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _quantityController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'الكمية المتوفرة', border: OutlineInputBorder()),
              validator: (v) => (v == null || int.tryParse(v.trim()) == null) ? 'رقم غير صحيح' : null,
            ),
            const SizedBox(height: 12),
            _buildImagesPicker(),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('عرض ضمن التخفيضات'),
              value: _isOffer,
              onChanged: (v) => setState(() => _isOffer = v),
            ),
            if (_category?.slug == 'real_estate') ...[
              const Divider(height: 32),
              Text('تفاصيل العقار', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 12),
              _buildRealEstateFields(),
            ],
            if (_category?.slug == 'phones') ...[
              const Divider(height: 32),
              Text('تفاصيل الهاتف', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 12),
              _buildPhoneFields(),
            ],
            if (_category?.slug == 'generators') ...[
              const Divider(height: 32),
              Text('تفاصيل الماطور/المولدة', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 12),
              _buildGeneratorFields(),
            ],
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _isSaving ? null : _submit,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              child: _isSaving
                  ? const SizedBox(
                      width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Text('نشر المنتج'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildImagesPicker() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('صور المنتج', style: TextStyle(fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        SizedBox(
          height: 90,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: [
              for (var i = 0; i < _imageUrls.length; i++)
                Padding(
                  padding: const EdgeInsets.only(left: 8),
                  child: Stack(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: CachedNetworkImage(
                          imageUrl: _imageUrls[i],
                          width: 80, height: 80, fit: BoxFit.cover,
                        ),
                      ),
                      Positioned(
                        top: 2, left: 2,
                        child: GestureDetector(
                          onTap: () => setState(() => _imageUrls.removeAt(i)),
                          child: const CircleAvatar(
                            radius: 10,
                            backgroundColor: AppColors.danger,
                            child: Icon(Icons.close, size: 12, color: Colors.white),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              InkWell(
                onTap: _isUploadingImage ? null : _pickImages,
                borderRadius: BorderRadius.circular(8),
                child: Container(
                  width: 80, height: 80,
                  decoration: BoxDecoration(
                    color: AppColors.primaryLight,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: _isUploadingImage
                      ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.add_a_photo_outlined, color: AppColors.primary),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
      ],
    );
  }

  Widget _buildRealEstateFields() {
    return Column(
      children: [
        DropdownButtonFormField<String>(
          initialValue: _listingType,
          decoration: const InputDecoration(labelText: 'نوع العرض', border: OutlineInputBorder()),
          items: const [
            DropdownMenuItem(value: 'sale', child: Text('بيع')),
            DropdownMenuItem(value: 'rent', child: Text('إيجار')),
          ],
          onChanged: (v) => setState(() => _listingType = v!),
        ),
        const SizedBox(height: 12),
        TextFormField(
          controller: _propertyTypeController,
          decoration: const InputDecoration(labelText: 'نوع العقار (شقة، بيت...)', border: OutlineInputBorder()),
          validator: (v) => (v == null || v.trim().isEmpty) ? 'مطلوب' : null,
        ),
        const SizedBox(height: 12),
        TextFormField(
          controller: _governorateController,
          decoration: const InputDecoration(labelText: 'المحافظة', border: OutlineInputBorder()),
          validator: (v) => (v == null || v.trim().isEmpty) ? 'مطلوب' : null,
        ),
        const SizedBox(height: 12),
        TextFormField(
          controller: _regionController,
          decoration: const InputDecoration(labelText: 'المنطقة', border: OutlineInputBorder()),
          validator: (v) => (v == null || v.trim().isEmpty) ? 'مطلوب' : null,
        ),
        const SizedBox(height: 12),
        TextFormField(
          controller: _areaController,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(labelText: 'المساحة (م²)', border: OutlineInputBorder()),
          validator: (v) => (v == null || double.tryParse(v.trim()) == null) ? 'رقم غير صحيح' : null,
        ),
        const SizedBox(height: 12),
        TextFormField(
          controller: _roomsController,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'عدد الغرف (اختياري)', border: OutlineInputBorder()),
        ),
        const SizedBox(height: 12),
        TextFormField(
          controller: _contactPhoneController,
          decoration: const InputDecoration(labelText: 'هاتف التواصل', border: OutlineInputBorder()),
          validator: (v) => (v == null || v.trim().isEmpty) ? 'مطلوب' : null,
        ),
      ],
    );
  }

  Widget _buildPhoneFields() {
    return Column(
      children: [
        TextFormField(
          controller: _brandController,
          decoration: const InputDecoration(labelText: 'الماركة', border: OutlineInputBorder()),
          validator: (v) => (v == null || v.trim().isEmpty) ? 'مطلوب' : null,
        ),
        const SizedBox(height: 12),
        TextFormField(
          controller: _modelController,
          decoration: const InputDecoration(labelText: 'الموديل', border: OutlineInputBorder()),
          validator: (v) => (v == null || v.trim().isEmpty) ? 'مطلوب' : null,
        ),
        const SizedBox(height: 12),
        TextFormField(
          controller: _storageController,
          decoration: const InputDecoration(labelText: 'سعة التخزين', border: OutlineInputBorder()),
          validator: (v) => (v == null || v.trim().isEmpty) ? 'مطلوب' : null,
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          initialValue: _condition,
          decoration: const InputDecoration(labelText: 'الحالة', border: OutlineInputBorder()),
          items: const [
            DropdownMenuItem(value: 'new', child: Text('جديد')),
            DropdownMenuItem(value: 'used', child: Text('مستعمل')),
          ],
          onChanged: (v) => setState(() => _condition = v!),
        ),
        const SizedBox(height: 12),
        TextFormField(
          controller: _ramController,
          decoration: const InputDecoration(labelText: 'الرام (اختياري)', border: OutlineInputBorder()),
        ),
        const SizedBox(height: 12),
        TextFormField(
          controller: _colorController,
          decoration: const InputDecoration(labelText: 'اللون (اختياري)', border: OutlineInputBorder()),
        ),
        const SizedBox(height: 12),
        TextFormField(
          controller: _warrantyController,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'الضمان (بالأشهر)', border: OutlineInputBorder()),
        ),
      ],
    );
  }

  Widget _buildGeneratorFields() {
    return Column(
      children: [
        TextFormField(
          controller: _powerController,
          decoration: const InputDecoration(labelText: 'القدرة', border: OutlineInputBorder()),
          validator: (v) => (v == null || v.trim().isEmpty) ? 'مطلوب' : null,
        ),
        const SizedBox(height: 12),
        TextFormField(
          controller: _fuelController,
          decoration: const InputDecoration(labelText: 'نوع الوقود', border: OutlineInputBorder()),
          validator: (v) => (v == null || v.trim().isEmpty) ? 'مطلوب' : null,
        ),
        const SizedBox(height: 12),
        TextFormField(
          controller: _generatorBrandController,
          decoration: const InputDecoration(labelText: 'الماركة', border: OutlineInputBorder()),
          validator: (v) => (v == null || v.trim().isEmpty) ? 'مطلوب' : null,
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          initialValue: _condition,
          decoration: const InputDecoration(labelText: 'الحالة', border: OutlineInputBorder()),
          items: const [
            DropdownMenuItem(value: 'new', child: Text('جديد')),
            DropdownMenuItem(value: 'used', child: Text('مستعمل')),
          ],
          onChanged: (v) => setState(() => _condition = v!),
        ),
        const SizedBox(height: 12),
        TextFormField(
          controller: _operatingHoursController,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'ساعات التشغيل (اختياري)', border: OutlineInputBorder()),
        ),
        const SizedBox(height: 12),
        TextFormField(
          controller: _manufactureYearController,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'سنة الصنع (اختياري)', border: OutlineInputBorder()),
        ),
        const SizedBox(height: 12),
        TextFormField(
          controller: _locationController,
          decoration: const InputDecoration(labelText: 'الموقع (اختياري)', border: OutlineInputBorder()),
        ),
      ],
    );
  }
}
