import '../../../../core/network/supabase_config.dart';
import '../models/category_model.dart';
import '../models/product_model.dart';

/// عمود select الموحّد لجلب منتج كامل مع كل علاقاته بطلب واحد،
/// لتفادي طلبات متعددة (N+1) عند عرض قائمة منتجات.
/// عام (بدون _) ليُعاد استخدامه من مستودعات أخرى (السلة، المفضلة، الطلبات)
/// عند تضمين المنتج داخل استعلام متداخل.
const productSelectFragment = '''
  id, seller_id, category_id, title, description, price, discount_price,
  quantity, is_offer, video_url, status, created_at,
  seller:sellers(store_name),
  category:categories(slug, name),
  product_images(image_url, sort_order),
  real_estate_details(*),
  phone_details(*),
  generator_details(*)
''';

class ProductsRepository {
  /// يجلب كل الأقسام النشطة مرتبة حسب sort_order.
  Future<List<CategoryModel>> fetchCategories() async {
    final rows = await supabase
        .from('categories')
        .select()
        .eq('is_active', true)
        .order('sort_order');
    return rows.map((e) => CategoryModel.fromJson(e)).toList();
  }

  /// يجلب المنتجات النشطة ضمن قسم معيّن.
  Future<List<ProductModel>> fetchProductsByCategory(
    int categoryId, {
    int limit = 20,
    int offset = 0,
  }) async {
    final rows = await supabase
        .from('products')
        .select(productSelectFragment)
        .eq('category_id', categoryId)
        .eq('status', 'active')
        .order('created_at', ascending: false)
        .range(offset, offset + limit - 1);
    return rows.map((e) => ProductModel.fromJson(e)).toList();
  }

  /// يجلب المنتجات المعروضة كعروض/تخفيضات (is_offer = true).
  Future<List<ProductModel>> fetchOffers({int limit = 20, int offset = 0}) async {
    final rows = await supabase
        .from('products')
        .select(productSelectFragment)
        .eq('is_offer', true)
        .eq('status', 'active')
        .order('created_at', ascending: false)
        .range(offset, offset + limit - 1);
    return rows.map((e) => ProductModel.fromJson(e)).toList();
  }

  /// يجلب تفاصيل منتج واحد بالكامل مع تفاصيله المتخصصة، ويزيد عدّاد المشاهدات.
  Future<ProductModel> fetchProductDetails(int productId) async {
    final row = await supabase.from('products').select(productSelectFragment).eq('id', productId).single();
    // زيادة عدّاد المشاهدات دون انتظار (لا يوقف عرض الشاشة إن فشل)
    unawaited(_incrementViews(productId));
    return ProductModel.fromJson(row);
  }

  Future<void> _incrementViews(int productId) async {
    try {
      await supabase.rpc('increment_product_views', params: {'p_product_id': productId});
    } catch (_) {
      // غير حرج — نتجاهل أي خطأ هنا
    }
  }

  /// بحث نصي بسيط في عنوان المنتج ووصفه.
  Future<List<ProductModel>> searchProducts(String query, {int limit = 20}) async {
    final rows = await supabase
        .from('products')
        .select(productSelectFragment)
        .eq('status', 'active')
        .or('title.ilike.%$query%,description.ilike.%$query%')
        .order('created_at', ascending: false)
        .limit(limit);
    return rows.map((e) => ProductModel.fromJson(e)).toList();
  }
}

final productsRepository = ProductsRepository();

// نستخدم unawaited من dart:async بشكل مبسّط هنا لتفادي إضافة استيراد إضافي بلا داعٍ
void unawaited(Future<void> future) {}
