/// النموذج العام للمنتج — يطابق جدول products في قاعدة البيانات.
/// الحقول المخصّصة لكل قسم (عقارات/هواتف/ماطورات) موجودة في [categoryDetails].
class ProductModel {
  final int id;
  final String sellerId;
  final String sellerName;
  final int categoryId;
  final String categorySlug;
  final String categoryName;
  final String title;
  final String? description;
  final double price;
  final double? discountPrice;
  final int quantity;
  final bool isOffer;
  final String status;
  final List<String> imageUrls;
  final String? videoUrl;

  /// يحمل واحدًا من: RealEstateDetails / PhoneDetails / GeneratorDetails / null
  final CategoryDetails? categoryDetails;

  const ProductModel({
    required this.id,
    required this.sellerId,
    required this.sellerName,
    required this.categoryId,
    required this.categorySlug,
    required this.categoryName,
    required this.title,
    this.description,
    required this.price,
    this.discountPrice,
    required this.quantity,
    this.isOffer = false,
    this.status = 'active',
    this.imageUrls = const [],
    this.videoUrl,
    this.categoryDetails,
  });

  double get displayPrice => discountPrice ?? price;
  bool get hasDiscount => discountPrice != null && discountPrice! < price;

  /// يبني النموذج من استعلام Supabase المتداخل (nested select)، مثال:
  /// products.select('*, seller:sellers(store_name), category:categories(slug,name),
  ///   product_images(image_url,sort_order), real_estate_details(*), phone_details(*), generator_details(*)')
  factory ProductModel.fromJson(Map<String, dynamic> json) {
    final categorySlug = (json['category'] as Map<String, dynamic>?)?['slug'] as String? ?? '';

    final images = (json['product_images'] as List<dynamic>? ?? [])
        .map((e) => e as Map<String, dynamic>)
        .toList()
      ..sort((a, b) => (a['sort_order'] as int).compareTo(b['sort_order'] as int));

    CategoryDetails? details;
    final realEstate = json['real_estate_details'];
    final phone = json['phone_details'];
    final generator = json['generator_details'];
    if (realEstate is Map<String, dynamic>) {
      details = RealEstateDetails.fromJson(realEstate);
    } else if (realEstate is List && realEstate.isNotEmpty) {
      details = RealEstateDetails.fromJson(realEstate.first as Map<String, dynamic>);
    } else if (phone is Map<String, dynamic>) {
      details = PhoneDetails.fromJson(phone);
    } else if (phone is List && phone.isNotEmpty) {
      details = PhoneDetails.fromJson(phone.first as Map<String, dynamic>);
    } else if (generator is Map<String, dynamic>) {
      details = GeneratorDetails.fromJson(generator);
    } else if (generator is List && generator.isNotEmpty) {
      details = GeneratorDetails.fromJson(generator.first as Map<String, dynamic>);
    }

    return ProductModel(
      id: json['id'] as int,
      sellerId: json['seller_id'] as String,
      sellerName: (json['seller'] as Map<String, dynamic>?)?['store_name'] as String? ?? '',
      categoryId: json['category_id'] as int,
      categorySlug: categorySlug,
      categoryName: (json['category'] as Map<String, dynamic>?)?['name'] as String? ?? '',
      title: json['title'] as String,
      description: json['description'] as String?,
      price: (json['price'] as num).toDouble(),
      discountPrice: (json['discount_price'] as num?)?.toDouble(),
      quantity: json['quantity'] as int,
      isOffer: json['is_offer'] as bool? ?? false,
      status: json['status'] as String? ?? 'active',
      imageUrls: images.map((e) => e['image_url'] as String).toList(),
      videoUrl: json['video_url'] as String?,
      categoryDetails: details,
    );
  }
}

/// نوع أساسي لكل الحقول المخصّصة حسب القسم
sealed class CategoryDetails {
  const CategoryDetails();
}

/// حقول قسم العقارات
class RealEstateDetails extends CategoryDetails {
  final String listingType; // 'sale' | 'rent'
  final String propertyType; // شقة، بيت، أرض، محل تجاري...
  final String governorate;
  final String region;
  final double areaSqm;
  final int? roomsCount;
  final String contactPhone;

  const RealEstateDetails({
    required this.listingType,
    required this.propertyType,
    required this.governorate,
    required this.region,
    required this.areaSqm,
    this.roomsCount,
    required this.contactPhone,
  });

  factory RealEstateDetails.fromJson(Map<String, dynamic> json) => RealEstateDetails(
        listingType: json['listing_type'] as String,
        propertyType: json['property_type'] as String,
        governorate: json['governorate'] as String,
        region: json['region'] as String,
        areaSqm: (json['area_sqm'] as num).toDouble(),
        roomsCount: json['rooms_count'] as int?,
        contactPhone: json['contact_phone'] as String,
      );
}

/// حقول قسم الهواتف
class PhoneDetails extends CategoryDetails {
  final String brand;
  final String model;
  final String storageCapacity;
  final String condition; // 'new' | 'used'
  final String? ram;
  final String? color;
  final int warrantyMonths;

  const PhoneDetails({
    required this.brand,
    required this.model,
    required this.storageCapacity,
    required this.condition,
    this.ram,
    this.color,
    this.warrantyMonths = 0,
  });

  factory PhoneDetails.fromJson(Map<String, dynamic> json) => PhoneDetails(
        brand: json['brand'] as String,
        model: json['model'] as String,
        storageCapacity: json['storage_capacity'] as String,
        condition: json['condition'] as String,
        ram: json['ram'] as String?,
        color: json['color'] as String?,
        warrantyMonths: json['warranty_months'] as int? ?? 0,
      );
}

/// حقول قسم الماطورات والمولدات
class GeneratorDetails extends CategoryDetails {
  final String powerRating;
  final String fuelType;
  final String brand;
  final String condition; // 'new' | 'used'
  final int? operatingHours;
  final int? manufactureYear;
  final String? location;

  const GeneratorDetails({
    required this.powerRating,
    required this.fuelType,
    required this.brand,
    required this.condition,
    this.operatingHours,
    this.manufactureYear,
    this.location,
  });

  factory GeneratorDetails.fromJson(Map<String, dynamic> json) => GeneratorDetails(
        powerRating: json['power_rating'] as String,
        fuelType: json['fuel_type'] as String,
        brand: json['brand'] as String,
        condition: json['condition'] as String,
        operatingHours: json['operating_hours'] as int?,
        manufactureYear: json['manufacture_year'] as int?,
        location: json['location'] as String?,
      );
}
