import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/models/category_model.dart';
import '../../data/models/product_model.dart';
import '../../data/repositories/products_repository.dart';

/// كل الأقسام النشطة، مرتبة حسب sort_order.
final categoriesProvider = FutureProvider<List<CategoryModel>>((ref) {
  return productsRepository.fetchCategories();
});

/// منتجات قسم معيّن — يُعاد جلبها تلقائيًا إذا تغيّر معرّف القسم.
final productsByCategoryProvider =
    FutureProvider.family<List<ProductModel>, int>((ref, categoryId) {
  return productsRepository.fetchProductsByCategory(categoryId);
});

/// منتجات العروض والتخفيضات.
final offersProvider = FutureProvider<List<ProductModel>>((ref) {
  return productsRepository.fetchOffers();
});

/// تفاصيل منتج واحد.
final productDetailsProvider = FutureProvider.family<ProductModel, int>((ref, productId) {
  return productsRepository.fetchProductDetails(productId);
});

/// نتائج البحث — يعاد تنفيذه كلما تغيّر نص البحث.
final searchQueryProvider = StateProvider<String>((ref) => '');

final searchResultsProvider = FutureProvider<List<ProductModel>>((ref) {
  final query = ref.watch(searchQueryProvider).trim();
  if (query.isEmpty) return Future.value(const []);
  return productsRepository.searchProducts(query);
});
