import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../../../core/theme/app_colors.dart';
import '../../data/models/product_model.dart';
import '../providers/products_provider.dart';
import '../../../cart/presentation/providers/cart_provider.dart';
import '../../../favorites/presentation/providers/favorites_provider.dart';

class ProductDetailsScreen extends ConsumerWidget {
  const ProductDetailsScreen({super.key, required this.productId});

  final int productId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final productAsync = ref.watch(productDetailsProvider(productId));
    final isFavorite = ref.watch(favoritesProvider).isFavorite(productId);

    return Scaffold(
      body: productAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, _) => Center(child: Text('تعذّر تحميل المنتج: $error')),
        data: (product) => _ProductDetailsBody(product: product),
      ),
      bottomNavigationBar: productAsync.maybeWhen(
        data: (product) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                IconButton.filledTonal(
                  onPressed: () => ref.read(favoritesProvider.notifier).toggle(productId),
                  icon: Icon(
                    isFavorite ? Icons.favorite : Icons.favorite_border,
                    color: isFavorite ? AppColors.danger : null,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () async {
                      await ref.read(cartProvider.notifier).addToCart(productId);
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('أُضيف المنتج إلى السلة')),
                        );
                      }
                    },
                    icon: const Icon(Icons.add_shopping_cart_outlined),
                    label: const Text('أضف للسلة'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primary,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        orElse: () => null,
      ),
    );
  }
}

class _ProductDetailsBody extends StatelessWidget {
  const _ProductDetailsBody({required this.product});
  final ProductModel product;

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      slivers: [
        SliverAppBar(
          expandedHeight: 320,
          pinned: true,
          flexibleSpace: FlexibleSpaceBar(
            background: _ImageCarousel(imageUrls: product.imageUrls),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  product.title,
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Text(
                      '${product.displayPrice.toStringAsFixed(0)} د.ع',
                      style: const TextStyle(
                        color: AppColors.primary,
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                      ),
                    ),
                    if (product.hasDiscount) ...[
                      const SizedBox(width: 10),
                      Text(
                        '${product.price.toStringAsFixed(0)} د.ع',
                        style: const TextStyle(
                          color: AppColors.textSecondary,
                          decoration: TextDecoration.lineThrough,
                        ),
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 4),
                Text('البائع: ${product.sellerName}', style: const TextStyle(color: AppColors.textSecondary)),
                const Divider(height: 32),
                if (product.categoryDetails != null) ...[
                  _CategorySpecificDetails(details: product.categoryDetails!),
                  const Divider(height: 32),
                ],
                if (product.description != null && product.description!.isNotEmpty) ...[
                  Text('الوصف', style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 8),
                  Text(product.description!, style: const TextStyle(height: 1.5)),
                  const SizedBox(height: 24),
                ],
              ],
            ),
          ),
        ),
      ],
      // شريط سفلي بسيط لإضافة المنتج للسلة (سيُفعَّل بخطوة السلة القادمة)
      // مُبقى هنا كتذكير مكاني فقط.
    );
  }
}

class _ImageCarousel extends StatefulWidget {
  const _ImageCarousel({required this.imageUrls});
  final List<String> imageUrls;

  @override
  State<_ImageCarousel> createState() => _ImageCarouselState();
}

class _ImageCarouselState extends State<_ImageCarousel> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    if (widget.imageUrls.isEmpty) {
      return Container(
        color: AppColors.primaryLight,
        child: const Icon(Icons.image_outlined, size: 64, color: AppColors.primary),
      );
    }
    return Stack(
      fit: StackFit.expand,
      children: [
        PageView.builder(
          itemCount: widget.imageUrls.length,
          onPageChanged: (i) => setState(() => _index = i),
          itemBuilder: (context, i) => CachedNetworkImage(
            imageUrl: widget.imageUrls[i],
            fit: BoxFit.cover,
            placeholder: (_, __) => Container(color: AppColors.primaryLight),
          ),
        ),
        if (widget.imageUrls.length > 1)
          Positioned(
            bottom: 12,
            left: 0,
            right: 0,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                widget.imageUrls.length,
                (i) => Container(
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  width: i == _index ? 18 : 6,
                  height: 6,
                  decoration: BoxDecoration(
                    color: i == _index ? Colors.white : Colors.white54,
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}

/// يعرض الحقول المتخصصة حسب نوع القسم باستخدام مطابقة الأنماط (pattern matching)
class _CategorySpecificDetails extends StatelessWidget {
  const _CategorySpecificDetails({required this.details});
  final CategoryDetails details;

  @override
  Widget build(BuildContext context) {
    final rows = switch (details) {
      RealEstateDetails d => [
          _row('نوع العرض', d.listingType == 'sale' ? 'بيع' : 'إيجار'),
          _row('نوع العقار', d.propertyType),
          _row('المحافظة', d.governorate),
          _row('المنطقة', d.region),
          _row('المساحة', '${d.areaSqm.toStringAsFixed(0)} م²'),
          if (d.roomsCount != null) _row('عدد الغرف', '${d.roomsCount}'),
          _row('هاتف التواصل', d.contactPhone),
        ],
      PhoneDetails d => [
          _row('الماركة', d.brand),
          _row('الموديل', d.model),
          _row('سعة التخزين', d.storageCapacity),
          _row('الحالة', d.condition == 'new' ? 'جديد' : 'مستعمل'),
          if (d.ram != null) _row('الرام', d.ram!),
          if (d.color != null) _row('اللون', d.color!),
          if (d.warrantyMonths > 0) _row('الضمان', '${d.warrantyMonths} شهر'),
        ],
      GeneratorDetails d => [
          _row('القدرة', d.powerRating),
          _row('نوع الوقود', d.fuelType),
          _row('الماركة', d.brand),
          _row('الحالة', d.condition == 'new' ? 'جديد' : 'مستعمل'),
          if (d.operatingHours != null) _row('ساعات التشغيل', '${d.operatingHours}'),
          if (d.manufactureYear != null) _row('سنة الصنع', '${d.manufactureYear}'),
          if (d.location != null) _row('الموقع', d.location!),
        ],
    };

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('المواصفات', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        ...rows,
      ],
    );
  }

  Widget _row(String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          children: [
            SizedBox(
              width: 110,
              child: Text(label, style: const TextStyle(color: AppColors.textSecondary)),
            ),
            Expanded(child: Text(value, style: const TextStyle(fontWeight: FontWeight.w600))),
          ],
        ),
      );
}
