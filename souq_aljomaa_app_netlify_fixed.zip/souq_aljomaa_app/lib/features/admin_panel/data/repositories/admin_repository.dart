import '../../../../core/network/supabase_config.dart';
import '../../../products/data/models/product_model.dart';
import '../../../products/data/repositories/products_repository.dart';
import '../models/admin_models.dart';

class AdminRepository {
  Future<PlatformSummaryModel> fetchPlatformSummary() async {
    final rows = await supabase.rpc('admin_platform_summary');
    if (rows is List && rows.isNotEmpty) {
      return PlatformSummaryModel.fromJson(rows.first as Map<String, dynamic>);
    }
    return PlatformSummaryModel.empty();
  }

  Future<List<PendingSellerModel>> fetchPendingSellers() async {
    final rows = await supabase
        .from('sellers')
        .select('id, store_name, store_description, profile:profiles(email)')
        .eq('approved_by_admin', false)
        .order('created_at');
    return rows.map((e) => PendingSellerModel.fromJson(e)).toList();
  }

  Future<void> approveSeller(String sellerId) async {
    await supabase.from('sellers').update({'approved_by_admin': true}).eq('id', sellerId);
    await supabase.from('profiles').update({'status': 'active'}).eq('id', sellerId);
  }

  Future<void> rejectSeller(String sellerId) async {
    await supabase.from('profiles').update({'status': 'rejected'}).eq('id', sellerId);
  }

  Future<List<PendingDeliveryCompanyModel>> fetchPendingDeliveryCompanies() async {
    final rows = await supabase
        .from('delivery_companies')
        .select('id, company_name, profile:profiles(email)')
        .eq('approved_by_admin', false)
        .order('created_at');
    return rows.map((e) => PendingDeliveryCompanyModel.fromJson(e)).toList();
  }

  Future<void> approveDeliveryCompany(String companyId) async {
    await supabase.from('delivery_companies').update({'approved_by_admin': true}).eq('id', companyId);
    await supabase.from('profiles').update({'status': 'active'}).eq('id', companyId);
  }

  Future<void> rejectDeliveryCompany(String companyId) async {
    await supabase.from('profiles').update({'status': 'rejected'}).eq('id', companyId);
  }

  Future<List<ProductModel>> fetchPendingProducts() async {
    final rows = await supabase
        .from('products')
        .select(productSelectFragment)
        .eq('status', 'pending_review')
        .order('created_at');
    return rows.map((e) => ProductModel.fromJson(e)).toList();
  }

  Future<void> approveProduct(int productId) async {
    await supabase.from('products').update({'status': 'active'}).eq('id', productId);
  }

  Future<void> rejectProduct(int productId) async {
    await supabase.from('products').update({'status': 'rejected'}).eq('id', productId);
  }

  Future<List<ComplaintModel>> fetchOpenComplaints() async {
    final rows = await supabase
        .from('complaints')
        .select()
        .eq('status', 'open')
        .order('created_at', ascending: false);
    return rows.map((e) => ComplaintModel.fromJson(e)).toList();
  }

  Future<void> resolveComplaint(int complaintId, {String? adminNotes}) async {
    await supabase.from('complaints').update({
      'status': 'resolved',
      'admin_notes': adminNotes,
      'resolved_at': DateTime.now().toIso8601String(),
    }).eq('id', complaintId);
  }

  Future<void> dismissComplaint(int complaintId, {String? adminNotes}) async {
    await supabase.from('complaints').update({
      'status': 'dismissed',
      'admin_notes': adminNotes,
      'resolved_at': DateTime.now().toIso8601String(),
    }).eq('id', complaintId);
  }
}

final adminRepository = AdminRepository();
