class PlatformSummaryModel {
  final int totalOrders;
  final int totalCustomers;
  final int totalSellers;
  final int totalDeliveryCompanies;
  final double totalRevenue;
  final double totalCommission;
  final int pendingSellers;
  final int pendingDeliveryCompanies;
  final int pendingProducts;
  final int openComplaints;

  const PlatformSummaryModel({
    required this.totalOrders,
    required this.totalCustomers,
    required this.totalSellers,
    required this.totalDeliveryCompanies,
    required this.totalRevenue,
    required this.totalCommission,
    required this.pendingSellers,
    required this.pendingDeliveryCompanies,
    required this.pendingProducts,
    required this.openComplaints,
  });

  factory PlatformSummaryModel.fromJson(Map<String, dynamic> json) => PlatformSummaryModel(
        totalOrders: json['total_orders'] as int,
        totalCustomers: json['total_customers'] as int,
        totalSellers: json['total_sellers'] as int,
        totalDeliveryCompanies: json['total_delivery_companies'] as int,
        totalRevenue: (json['total_revenue'] as num).toDouble(),
        totalCommission: (json['total_commission'] as num).toDouble(),
        pendingSellers: json['pending_sellers'] as int,
        pendingDeliveryCompanies: json['pending_delivery_companies'] as int,
        pendingProducts: json['pending_products'] as int,
        openComplaints: json['open_complaints'] as int,
      );

  factory PlatformSummaryModel.empty() => const PlatformSummaryModel(
        totalOrders: 0, totalCustomers: 0, totalSellers: 0, totalDeliveryCompanies: 0,
        totalRevenue: 0, totalCommission: 0, pendingSellers: 0, pendingDeliveryCompanies: 0,
        pendingProducts: 0, openComplaints: 0,
      );
}

/// طلب بائع بانتظار موافقة الإدارة
class PendingSellerModel {
  final String id;
  final String storeName;
  final String? storeDescription;
  final String? email;

  const PendingSellerModel({required this.id, required this.storeName, this.storeDescription, this.email});

  factory PendingSellerModel.fromJson(Map<String, dynamic> json) {
    final profile = json['profile'] as Map<String, dynamic>?;
    return PendingSellerModel(
      id: json['id'] as String,
      storeName: json['store_name'] as String,
      storeDescription: json['store_description'] as String?,
      email: profile?['email'] as String?,
    );
  }
}

/// طلب شركة توصيل بانتظار موافقة الإدارة
class PendingDeliveryCompanyModel {
  final String id;
  final String companyName;
  final String? email;

  const PendingDeliveryCompanyModel({required this.id, required this.companyName, this.email});

  factory PendingDeliveryCompanyModel.fromJson(Map<String, dynamic> json) {
    final profile = json['profile'] as Map<String, dynamic>?;
    return PendingDeliveryCompanyModel(
      id: json['id'] as String,
      companyName: json['company_name'] as String,
      email: profile?['email'] as String?,
    );
  }
}

/// شكوى مرفوعة للإدارة
class ComplaintModel {
  final int id;
  final String subject;
  final String? description;
  final String status;
  final String againstRole;
  final DateTime createdAt;

  const ComplaintModel({
    required this.id,
    required this.subject,
    this.description,
    required this.status,
    required this.againstRole,
    required this.createdAt,
  });

  factory ComplaintModel.fromJson(Map<String, dynamic> json) => ComplaintModel(
        id: json['id'] as int,
        subject: json['subject'] as String,
        description: json['description'] as String?,
        status: json['status'] as String,
        againstRole: json['against_role'] as String,
        createdAt: DateTime.parse(json['created_at'] as String),
      );
}
