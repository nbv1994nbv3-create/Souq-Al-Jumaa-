import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../products/data/models/product_model.dart';
import '../../data/models/admin_models.dart';
import '../../data/repositories/admin_repository.dart';

final platformSummaryProvider = FutureProvider<PlatformSummaryModel>((ref) {
  return adminRepository.fetchPlatformSummary();
});

final pendingSellersProvider = FutureProvider<List<PendingSellerModel>>((ref) {
  return adminRepository.fetchPendingSellers();
});

final pendingDeliveryCompaniesProvider = FutureProvider<List<PendingDeliveryCompanyModel>>((ref) {
  return adminRepository.fetchPendingDeliveryCompanies();
});

final pendingProductsProvider = FutureProvider<List<ProductModel>>((ref) {
  return adminRepository.fetchPendingProducts();
});

final openComplaintsProvider = FutureProvider<List<ComplaintModel>>((ref) {
  return adminRepository.fetchOpenComplaints();
});
