import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../data/models/admin_models.dart';
import '../../data/repositories/admin_repository.dart';
import '../providers/admin_provider.dart';

class PendingSellersScreen extends ConsumerWidget {
  const PendingSellersScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sellersAsync = ref.watch(pendingSellersProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('طلبات فتح متاجر')),
      body: sellersAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('تعذّر التحميل: $e')),
        data: (sellers) => sellers.isEmpty
            ? const Center(child: Text('لا توجد طلبات بانتظار المراجعة'))
            : ListView.separated(
                padding: const EdgeInsets.all(12),
                itemCount: sellers.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (context, i) => _SellerTile(seller: sellers[i]),
              ),
      ),
    );
  }
}

class _SellerTile extends ConsumerWidget {
  const _SellerTile({required this.seller});
  final PendingSellerModel seller;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(seller.storeName, style: const TextStyle(fontWeight: FontWeight.w700)),
          if (seller.email != null)
            Text(seller.email!, style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
          if (seller.storeDescription != null && seller.storeDescription!.isNotEmpty) ...[
            const SizedBox(height: 4),
            Text(seller.storeDescription!, style: const TextStyle(fontSize: 13)),
          ],
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () async {
                    await adminRepository.rejectSeller(seller.id);
                    ref.invalidate(pendingSellersProvider);
                  },
                  style: OutlinedButton.styleFrom(foregroundColor: AppColors.danger),
                  child: const Text('رفض'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: ElevatedButton(
                  onPressed: () async {
                    await adminRepository.approveSeller(seller.id);
                    ref.invalidate(pendingSellersProvider);
                    ref.invalidate(platformSummaryProvider);
                  },
                  style: ElevatedButton.styleFrom(backgroundColor: AppColors.success, foregroundColor: Colors.white),
                  child: const Text('موافقة'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
