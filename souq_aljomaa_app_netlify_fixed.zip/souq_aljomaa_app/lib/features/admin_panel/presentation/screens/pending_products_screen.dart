import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../products/data/models/product_model.dart';
import '../../data/repositories/admin_repository.dart';
import '../providers/admin_provider.dart';

class PendingProductsScreen extends ConsumerWidget {
  const PendingProductsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final productsAsync = ref.watch(pendingProductsProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('مراجعة المنتجات')),
      body: productsAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('تعذّر التحميل: $e')),
        data: (products) => products.isEmpty
            ? const Center(child: Text('لا توجد منتجات بانتظار المراجعة'))
            : ListView.separated(
                padding: const EdgeInsets.all(12),
                itemCount: products.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (context, i) => _ProductReviewTile(product: products[i]),
              ),
      ),
    );
  }
}

class _ProductReviewTile extends ConsumerWidget {
  const _ProductReviewTile({required this.product});
  final ProductModel product;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: SizedBox(
                  width: 56, height: 56,
                  child: product.imageUrls.isNotEmpty
                      ? CachedNetworkImage(imageUrl: product.imageUrls.first, fit: BoxFit.cover)
                      : Container(color: AppColors.primaryLight, child: const Icon(Icons.image_outlined)),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(product.title, style: const TextStyle(fontWeight: FontWeight.w700)),
                    Text('${product.sellerName} · ${product.categoryName}',
                        style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                    Text('${product.displayPrice.toStringAsFixed(0)} د.ع',
                        style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () async {
                    await adminRepository.rejectProduct(product.id);
                    ref.invalidate(pendingProductsProvider);
                  },
                  style: OutlinedButton.styleFrom(foregroundColor: AppColors.danger),
                  child: const Text('رفض'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: ElevatedButton(
                  onPressed: () async {
                    await adminRepository.approveProduct(product.id);
                    ref.invalidate(pendingProductsProvider);
                    ref.invalidate(platformSummaryProvider);
                  },
                  style: ElevatedButton.styleFrom(backgroundColor: AppColors.success, foregroundColor: Colors.white),
                  child: const Text('موافقة'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
