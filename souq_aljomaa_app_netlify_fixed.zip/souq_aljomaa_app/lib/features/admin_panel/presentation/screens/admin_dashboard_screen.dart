import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/theme/app_colors.dart';
import '../providers/admin_provider.dart';

class AdminDashboardScreen extends ConsumerWidget {
  const AdminDashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final summaryAsync = ref.watch(platformSummaryProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('لوحة الإدارة')),
      body: summaryAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('تعذّر تحميل الملخص: $e')),
        data: (summary) => RefreshIndicator(
          onRefresh: () async => ref.invalidate(platformSummaryProvider),
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Row(
                children: [
                  Expanded(child: _StatCard(label: 'الطلبات', value: '${summary.totalOrders}')),
                  const SizedBox(width: 10),
                  Expanded(child: _StatCard(label: 'الإيرادات', value: '${summary.totalRevenue.toStringAsFixed(0)}')),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(child: _StatCard(label: 'عمولة المنصة', value: '${summary.totalCommission.toStringAsFixed(0)}')),
                  const SizedBox(width: 10),
                  Expanded(child: _StatCard(label: 'الزبائن', value: '${summary.totalCustomers}')),
                ],
              ),
              const SizedBox(height: 24),
              Text('بانتظار المراجعة', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 10),
              _ActionTile(
                icon: Icons.storefront_outlined,
                title: 'طلبات فتح متاجر',
                badge: summary.pendingSellers,
                onTap: () => context.push('/admin/sellers'),
              ),
              const SizedBox(height: 10),
              _ActionTile(
                icon: Icons.local_shipping_outlined,
                title: 'طلبات شركات التوصيل',
                badge: summary.pendingDeliveryCompanies,
                onTap: () => context.push('/admin/delivery-companies'),
              ),
              const SizedBox(height: 10),
              _ActionTile(
                icon: Icons.inventory_2_outlined,
                title: 'مراجعة المنتجات',
                badge: summary.pendingProducts,
                onTap: () => context.push('/admin/products'),
              ),
              const SizedBox(height: 10),
              _ActionTile(
                icon: Icons.report_gmailerrorred_outlined,
                title: 'الشكاوى',
                badge: summary.openComplaints,
                onTap: () => context.push('/admin/complaints'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.primaryLight,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: AppColors.primaryDark)),
          Text(label, style: const TextStyle(fontSize: 12, color: AppColors.primaryDark)),
        ],
      ),
    );
  }
}

class _ActionTile extends StatelessWidget {
  const _ActionTile({required this.icon, required this.title, required this.badge, required this.onTap});
  final IconData icon;
  final String title;
  final int badge;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            Icon(icon, color: AppColors.primary),
            const SizedBox(width: 12),
            Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w600))),
            if (badge > 0)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(color: AppColors.danger, borderRadius: BorderRadius.circular(10)),
                child: Text('$badge', style: const TextStyle(color: Colors.white, fontSize: 12)),
              ),
            const SizedBox(width: 8),
            const Icon(Icons.arrow_back_ios, size: 14, color: AppColors.textSecondary),
          ],
        ),
      ),
    );
  }
}
