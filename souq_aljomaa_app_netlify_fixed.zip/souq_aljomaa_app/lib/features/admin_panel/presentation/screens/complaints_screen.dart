import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../data/models/admin_models.dart';
import '../../data/repositories/admin_repository.dart';
import '../providers/admin_provider.dart';

const _roleLabels = {'seller': 'بائع', 'delivery_company': 'شركة توصيل'};

class ComplaintsScreen extends ConsumerWidget {
  const ComplaintsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final complaintsAsync = ref.watch(openComplaintsProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('الشكاوى')),
      body: complaintsAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('تعذّر التحميل: $e')),
        data: (complaints) => complaints.isEmpty
            ? const Center(child: Text('لا توجد شكاوى مفتوحة'))
            : ListView.separated(
                padding: const EdgeInsets.all(12),
                itemCount: complaints.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (context, i) => _ComplaintTile(complaint: complaints[i]),
              ),
      ),
    );
  }
}

class _ComplaintTile extends ConsumerWidget {
  const _ComplaintTile({required this.complaint});
  final ComplaintModel complaint;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text(complaint.subject, style: const TextStyle(fontWeight: FontWeight.w700))),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(color: AppColors.warning.withOpacity(0.15), borderRadius: BorderRadius.circular(8)),
                child: Text(_roleLabels[complaint.againstRole] ?? complaint.againstRole,
                    style: const TextStyle(color: AppColors.warning, fontSize: 11)),
              ),
            ],
          ),
          if (complaint.description != null && complaint.description!.isNotEmpty) ...[
            const SizedBox(height: 6),
            Text(complaint.description!, style: const TextStyle(fontSize: 13, color: AppColors.textSecondary)),
          ],
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () async {
                    await adminRepository.dismissComplaint(complaint.id);
                    ref.invalidate(openComplaintsProvider);
                  },
                  child: const Text('تجاهل'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: ElevatedButton(
                  onPressed: () async {
                    await adminRepository.resolveComplaint(complaint.id);
                    ref.invalidate(openComplaintsProvider);
                  },
                  style: ElevatedButton.styleFrom(backgroundColor: AppColors.success, foregroundColor: Colors.white),
                  child: const Text('حُلّت'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
