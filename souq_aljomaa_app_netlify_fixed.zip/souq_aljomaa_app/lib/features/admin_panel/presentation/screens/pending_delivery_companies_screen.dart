import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_colors.dart';
import '../../data/models/admin_models.dart';
import '../../data/repositories/admin_repository.dart';
import '../providers/admin_provider.dart';

class PendingDeliveryCompaniesScreen extends ConsumerWidget {
  const PendingDeliveryCompaniesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final companiesAsync = ref.watch(pendingDeliveryCompaniesProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('طلبات شركات التوصيل')),
      body: companiesAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('تعذّر التحميل: $e')),
        data: (companies) => companies.isEmpty
            ? const Center(child: Text('لا توجد طلبات بانتظار المراجعة'))
            : ListView.separated(
                padding: const EdgeInsets.all(12),
                itemCount: companies.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (context, i) => _CompanyTile(company: companies[i]),
              ),
      ),
    );
  }
}

class _CompanyTile extends ConsumerWidget {
  const _CompanyTile({required this.company});
  final PendingDeliveryCompanyModel company;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(company.companyName, style: const TextStyle(fontWeight: FontWeight.w700)),
          if (company.email != null)
            Text(company.email!, style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () async {
                    await adminRepository.rejectDeliveryCompany(company.id);
                    ref.invalidate(pendingDeliveryCompaniesProvider);
                  },
                  style: OutlinedButton.styleFrom(foregroundColor: AppColors.danger),
                  child: const Text('رفض'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: ElevatedButton(
                  onPressed: () async {
                    await adminRepository.approveDeliveryCompany(company.id);
                    ref.invalidate(pendingDeliveryCompaniesProvider);
                    ref.invalidate(platformSummaryProvider);
                  },
                  style: ElevatedButton.styleFrom(backgroundColor: AppColors.success, foregroundColor: Colors.white),
                  child: const Text('موافقة'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
