import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../data/repositories/auth_repository.dart';
import '../../../shared/models/user_model.dart';

/// يبث تغيّرات حالة المصادقة الخام من Supabase (تسجيل دخول/خروج).
final authStateProvider = StreamProvider<AuthState>((ref) {
  return authRepository.authStateChanges;
});

/// يبث بيانات المستخدم الحالي (صف profiles) ويُعاد تحميله تلقائيًا
/// كلما تغيّرت حالة المصادقة (دخول/خروج).
final currentUserProvider = FutureProvider<UserModel?>((ref) async {
  // إعادة التنفيذ عند أي تغيّر بحالة المصادقة
  ref.watch(authStateProvider);
  return authRepository.currentProfile();
});

/// حالة إرسال/التحقق من OTP لشاشات تسجيل الدخول.
enum OtpStep { enterEmail, enterCode }

class AuthFlowState {
  const AuthFlowState({
    this.step = OtpStep.enterEmail,
    this.email,
    this.isLoading = false,
    this.errorMessage,
  });

  final OtpStep step;
  final String? email;
  final bool isLoading;
  final String? errorMessage;

  AuthFlowState copyWith({
    OtpStep? step,
    String? email,
    bool? isLoading,
    String? errorMessage,
  }) {
    return AuthFlowState(
      step: step ?? this.step,
      email: email ?? this.email,
      isLoading: isLoading ?? false,
      errorMessage: errorMessage,
    );
  }
}

class AuthFlowController extends StateNotifier<AuthFlowState> {
  AuthFlowController() : super(const AuthFlowState());

  Future<void> sendOtp(String email) async {
    state = state.copyWith(isLoading: true, errorMessage: null);
    try {
      await authRepository.sendOtp(email);
      state = state.copyWith(step: OtpStep.enterCode, email: email, isLoading: false);
    } catch (e) {
      state = state.copyWith(isLoading: false, errorMessage: e.toString());
    }
  }

  Future<bool> verifyOtp(String otp) async {
    if (state.email == null) return false;
    state = state.copyWith(isLoading: true, errorMessage: null);
    try {
      await authRepository.verifyOtp(email: state.email!, otp: otp);
      state = state.copyWith(isLoading: false);
      return true;
    } catch (e) {
      state = state.copyWith(isLoading: false, errorMessage: e.toString());
      return false;
    }
  }

  void resetToEmailStep() => state = const AuthFlowState();
}

final authFlowProvider = StateNotifierProvider<AuthFlowController, AuthFlowState>((ref) {
  return AuthFlowController();
});
