import 'package:supabase_flutter/supabase_flutter.dart';
import '../../../../core/network/supabase_config.dart';
import '../../../../shared/models/user_model.dart';

/// استثناء مخصص لعرض رسائل مصادقة مفهومة للمستخدم.
class AuthFailure implements Exception {
  const AuthFailure(this.message);
  final String message;
  @override
  String toString() => message;
}

/// طبقة الوصول لعمليات المصادقة: تسجيل دخول/تسجيل حساب جديد بالبريد
/// الإلكتروني عبر رمز تحقق (OTP)، وجلب صف profiles المرتبط بالحساب.
///
/// ملاحظة: نستخدم البريد الإلكتروني بدل رقم الهاتف مؤقتًا في مرحلة
/// التطوير لأن الدخول بالهاتف يتطلب مزوّد SMS مدفوع (Twilio).
/// عند الانتقال للإنتاج يمكن التبديل لاحقًا بتغيير هذا الملف فقط
/// دون المساس بأي كود آخر في التطبيق (الواجهات تتعامل مع UserModel).
class AuthRepository {
  AuthRepository(this._client);
  final SupabaseClient _client;

  /// يرسل رمز تحقق (OTP) إلى البريد الإلكتروني.
  /// shouldCreateUser: true يسمح بإنشاء حساب جديد تلقائيًا إذا كان
  /// هذا أول دخول لهذا البريد.
  Future<void> sendOtp(String email) async {
    try {
      await _client.auth.signInWithOtp(email: email, shouldCreateUser: true);
    } on AuthException catch (e) {
      throw AuthFailure(e.message);
    }
  }

  /// يتحقق من رمز الـ OTP، ويكمل تسجيل الدخول أو إنشاء الحساب تلقائيًا
  /// إذا كان أول مرة (المُشغّل on_auth_user_created في قاعدة البيانات
  /// ينشئ صف profiles تلقائيًا).
  Future<UserModel> verifyOtp({required String email, required String otp}) async {
    try {
      final response = await _client.auth.verifyOTP(
        email: email,
        token: otp,
        type: OtpType.email,
      );
      final authUser = response.user;
      if (authUser == null) {
        throw const AuthFailure('تعذّر التحقق من الرمز، حاول مرة أخرى');
      }
      return await _waitForProfile(authUser.id);
    } on AuthException catch (e) {
      throw AuthFailure(e.message);
    }
  }

  /// صف profiles يُنشأ عبر مُشغّل قاعدة بيانات بعد إنشاء المستخدم
  /// مباشرة، لذا نحاول عدة مرات لتفادي أي تأخير بسيط بالتزامن.
  Future<UserModel> _waitForProfile(String userId) async {
    for (var attempt = 0; attempt < 6; attempt++) {
      final row = await _client.from('profiles').select().eq('id', userId).maybeSingle();
      if (row != null) return UserModel.fromJson(row);
      await Future.delayed(const Duration(milliseconds: 350));
    }
    throw const AuthFailure('تعذّر تحميل بيانات الحساب، حاول لاحقًا');
  }

  /// يجلب صف المستخدم الحالي إن وجدت جلسة نشطة، وإلا null.
  Future<UserModel?> currentProfile() async {
    final userId = _client.auth.currentUser?.id;
    if (userId == null) return null;
    final row = await _client.from('profiles').select().eq('id', userId).maybeSingle();
    return row == null ? null : UserModel.fromJson(row);
  }

  /// تحديث بيانات الملف الشخصي (الاسم، الهاتف، الصورة).
  Future<UserModel> updateProfile({
    required String userId,
    String? fullName,
    String? phone,
    String? avatarUrl,
  }) async {
    final updates = <String, dynamic>{
      if (fullName != null) 'full_name': fullName,
      if (phone != null) 'phone': phone,
      if (avatarUrl != null) 'avatar_url': avatarUrl,
    };
    final row = await _client.from('profiles').update(updates).eq('id', userId).select().single();
    return UserModel.fromJson(row);
  }

  /// بث حالة المصادقة (دخول/خروج/تجديد جلسة).
  Stream<AuthState> get authStateChanges => _client.auth.onAuthStateChange;

  bool get isSignedIn => _client.auth.currentUser != null;

  Future<void> signOut() => _client.auth.signOut();
}

final authRepository = AuthRepository(supabase);
