# سوق الجمعة — تطبيق Flutter

هيكلية مشروع أولية لتطبيق **سوق الجمعة**، مبنية على بنية Feature-First مع دعم كامل لـ RTL والعربية، وقابلة للتوسّع لتشمل تطبيق الزبائن ولوحات البائعين وشركات التوصيل والإدارة من نفس قاعدة الكود.

## بنية المجلدات

```
lib/
├── main.dart                  # نقطة الدخول
├── app.dart                   # MaterialApp + إعداد RTL/العربية
├── core/                      # كل ما هو مشترك بين الميزات
│   ├── theme/                 # الألوان والخطوط (هوية سوق الجمعة)
│   ├── routing/                # go_router — مسارات كل الأدوار
│   ├── network/                 # عميل Dio + مسارات الـ API
│   ├── constants/
│   ├── utils/
│   └── widgets/                 # عناصر واجهة مشتركة (Loading, ErrorView...)
├── features/                  # كل ميزة في مجلد مستقل بنمط data/presentation
│   ├── auth/
│   ├── home/                   # الشاشة الرئيسية بالأقسام التسعة
│   ├── products/                # عرض/تفاصيل المنتج (عام + عقارات/هواتف/ماطورات)
│   ├── cart/
│   ├── checkout/                # العنوان → اختيار شركة التوصيل → التأكيد
│   ├── orders/                  # متابعة الطلب وتأكيد الاستلام (OTP)
│   ├── favorites/
│   ├── seller_panel/            # لوحة البائع (متجر، منتجات، طلبات، مبيعات)
│   ├── delivery_company_panel/  # لوحة شركة التوصيل (تسجيل، مناطق، طلبات)
│   └── admin_panel/             # لوحة الإدارة (موافقات، عمولات، تقارير)
└── shared/
    ├── models/                  # نماذج مشتركة (UserModel...)
    ├── providers/                # Riverpod providers مشتركة
    └── widgets/
```

## قرارات معمارية رئيسية

- **إدارة الحالة: Riverpod.** يسهّل فصل منطق كل ميزة، ويدعم اختبار الوحدات دون الحاجة لـ BuildContext.
- **التوجيه: go_router.** مسارات كل دور (زبون `/`, بائع `/seller/*`, توصيل `/delivery/*`, إدارة `/admin/*`) معرّفة في `core/routing/app_router.dart`، مع إمكانية إضافة `redirect` لاحقًا يتحقق من دور المستخدم (`UserRole`) قبل السماح بالدخول لمسار معيّن.
- **تطبيق واحد أم أربعة؟** يُنصح بالبدء بقاعدة كود Flutter واحدة تضم كل الأدوار الأربعة (كما في هذا الهيكل)، حيث تُبنى نسخ منفصلة لكل جمهور عبر Flutter Flavors (`--flavor customer`, `--flavor seller`, `--flavor delivery`, `--flavor admin`) عند الحاجة لاحقًا — هذا يوفّر تكرار الكود المشترك (الثيم، النماذج، عميل الشبكة) بنسبة كبيرة، مع إمكانية فصل كل جمهور في تطبيق مستقل على المتاجر إن رغبتم بذلك مستقبلًا.
- **نموذج المنتج متعدد الأشكال:** `ProductModel` يحمل حقولًا عامة + `categoryDetails` اختياري (`RealEstateDetails` / `PhoneDetails` / `GeneratorDetails`)، بما يطابق تصميم قاعدة البيانات (جدول `products` + جداول تفاصيل فرعية).
- **RTL:** يُفعَّل تلقائيًا بضبط `locale: Locale('ar')` في `MaterialApp.router` — لا حاجة لأي `Directionality` يدوي في الشاشات.
- **مثال متكامل:** `features/checkout/presentation/screens/delivery_company_selection_screen.dart` شاشة عاملة بالكامل تطبّق تصميم اختيار شركة التوصيل من وثيقة المتطلبات (ترتيب حسب الأقل تكلفة / الأسرع / الأعلى تقييمًا).

## نقاط تحتاج ربطًا فعليًا بالخادم قبل التشغيل

1. استبدال placeholders (`HomeScreen()` في المسارات المؤقتة داخل `app_router.dart`) بالشاشات الفعلية عند بنائها.
2. تفعيل Firebase للإشعارات (`main.dart` يحتوي التعليق التوضيحي لمكان الاستدعاء).
3. ضبط `API_BASE_URL` عبر `--dart-define=API_BASE_URL=https://...` عند البناء.
4. توليد ملفات `*.g.dart` بعد إضافة نماذج `freezed`/`json_serializable` عبر:
   ```bash
   flutter pub run build_runner build --delete-conflicting-outputs
   ```
5. إضافة ملفات خط Cairo الفعلية إلى `assets/fonts/` (السطر مذكور في `pubspec.yaml`).

## التشغيل

```bash
flutter pub get
flutter run --dart-define=API_BASE_URL=https://api.souqaljomaa.com/v1
```

يعمل على نفس قاعدة الكود عبر: `flutter run -d chrome` (ويب)، `flutter run -d windows`، `flutter run -d macos`، بالإضافة إلى Android وiOS.
